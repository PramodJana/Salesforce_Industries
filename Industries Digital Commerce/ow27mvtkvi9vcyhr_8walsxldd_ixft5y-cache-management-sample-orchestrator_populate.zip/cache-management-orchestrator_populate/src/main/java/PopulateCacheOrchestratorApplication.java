import com.fasterxml.jackson.core.JsonProcessingException;

import java.net.URISyntaxException;
import java.util.List;

public class PopulateCacheOrchestratorApplication {
    public static void main(String[] args) throws URISyntaxException, InterruptedException, JsonProcessingException {
        String accessToken = "00D5g000007oNZ4!AQwAQLpy1PKU81Ub3NjTmKRBDQBnH3wDDE16QDsAgVOuOZ7R2ge1pfR95x2pAKPPd6_m1e54UZDgMafg4zZAwaqfzWkDtOcm";
        String orgNamespace = "pr_dc_003";
        String instanceUrl = "https://vlocity391-dev-ed.my.salesforce.com";
        List<String> catalogCodes = List.of("PR4_CATALOG");

        PopulateCacheOrchestrator orchestrator = new PopulateCacheOrchestrator(
                accessToken, orgNamespace, instanceUrl, catalogCodes);

        orchestrator.populateCache();
    }
}
