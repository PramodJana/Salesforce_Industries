package me.pranav.APICallingService;

import java.util.List;

public interface ResponseRepository {
    List<String> fetchAllResponses();

    void save(String response);

    void clear();
}
