package me.pranav.ContainsOffer;

public class ContainsOfferRequestBody {
    public final String catalogCode;
    public final String ctxEligibilityCacheKey;
    public final String product;

    public ContainsOfferRequestBody(String catalogCode, String product, String ctxEligibilityCacheKey) {
        this.catalogCode = catalogCode;
        this.product = product;
        this.ctxEligibilityCacheKey = ctxEligibilityCacheKey;
    }
}
