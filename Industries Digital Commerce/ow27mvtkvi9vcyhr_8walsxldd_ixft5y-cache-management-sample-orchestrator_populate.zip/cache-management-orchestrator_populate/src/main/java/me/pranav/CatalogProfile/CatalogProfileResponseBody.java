package me.pranav.CatalogProfile;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CatalogProfileResponseBody {
    public CatalogDataAPIResponse apiResponse;
    public String catalogCode;

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CatalogDataAPIResponse {
        public CatalogProfileData data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CatalogProfileData {
        public CatalogProductRelationDetails catalogProductRelationDetails;
        public Map<String, List<String>> catalogCodeToRuleAssignments;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CatalogProductRelationDetails {
        public List<String> Promotion;
        public List<String> Product;
    }
}