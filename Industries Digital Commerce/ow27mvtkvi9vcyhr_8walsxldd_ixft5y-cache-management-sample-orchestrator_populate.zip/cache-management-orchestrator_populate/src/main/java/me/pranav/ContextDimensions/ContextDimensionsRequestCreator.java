package me.pranav.ContextDimensions;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

public class ContextDimensionsRequestCreator {
    private final String accessToken;
    private final String baseUrl;
    private final List<String> catalogCodes;

    public ContextDimensionsRequestCreator(String accessToken, String baseUrl, List<String> catalogCodes) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.catalogCodes = catalogCodes;
    }

    public List<HttpRequest> createRequests() throws URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();

        for (String code : catalogCodes) {
            HttpRequest request = HttpRequest.newBuilder()
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + this.accessToken)
                    .uri(new URI(baseUrl + "catalogs/" + code + "/contextdimensions"))
                    .GET()
                    .build();

            requests.add(request);
        }

        return requests;
    }
}
