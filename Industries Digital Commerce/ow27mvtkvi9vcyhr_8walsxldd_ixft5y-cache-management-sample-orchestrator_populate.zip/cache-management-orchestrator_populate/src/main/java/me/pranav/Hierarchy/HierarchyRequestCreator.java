package me.pranav.Hierarchy;

import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

public class HierarchyRequestCreator {
    private final String accessToken;
    private final String baseUrl;
    private final List<CatalogProfileResponseBody> profiles;

    public HierarchyRequestCreator(String accessToken, String baseUrl, List<CatalogProfileResponseBody> profiles) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.profiles = profiles;
    }

    public List<HttpRequest> createRequests() throws URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();
        for (CatalogProfileResponseBody profile : profiles)
            requests.addAll(createRequests(profile));
        return requests;
    }

    private List<HttpRequest> createRequests(CatalogProfileResponseBody profile) throws URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();
        List<String> products = profile.apiResponse.data.catalogProductRelationDetails.Product;
        for (String product : products)
            requests.add(getHttpRequest(profile, product));
        return requests;
    }

    private HttpRequest getHttpRequest(CatalogProfileResponseBody profile, String product) throws URISyntaxException {
        return HttpRequest.newBuilder()
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + accessToken)
                .uri(new URI(baseUrl + "catalogs/" + profile.catalogCode + "/offers/" + product + "/hierarchy"))
                .POST(HttpRequest.BodyPublishers.ofString("{}"))
                .build();
    }
}
