package me.pranav.APICallingService;

import java.util.Deque;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;

public class InMemoryResponseRepository implements ResponseRepository {
    Deque<String> inMemoryDB = new ConcurrentLinkedDeque<>();

    @Override
    public List<String> fetchAllResponses() {
        return List.copyOf(inMemoryDB);
    }

    @Override
    public void save(String response) {
        inMemoryDB.push(response);
    }

    @Override
    public void clear() {
        inMemoryDB.clear();
    }
}
