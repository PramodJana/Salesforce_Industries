package me.pranav.OffersItem;

import java.util.List;

public class OffersItemRequestBody {
    public String catalogCode;
    public List<String> offerIds;

    public OffersItemRequestBody(String catalogCode, List<String> offerIds) {
        this.catalogCode = catalogCode;
        this.offerIds = offerIds;
    }
}
