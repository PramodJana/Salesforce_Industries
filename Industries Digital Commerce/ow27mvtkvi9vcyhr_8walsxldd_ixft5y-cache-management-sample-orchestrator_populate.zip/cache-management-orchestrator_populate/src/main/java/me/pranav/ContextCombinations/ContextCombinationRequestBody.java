package me.pranav.ContextCombinations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContextCombinationRequestBody {
    public String catalogCode;
    public Map<String, List<String>> dimensions;
    public int pagesize;
    public int offset;
    public boolean validate;

    public ContextCombinationRequestBody(String catalogCode, int offset, int pagesize) {
        this.catalogCode = catalogCode;
        this.dimensions = new HashMap<>();
        this.pagesize = pagesize;
        this.offset = offset;
    }
}
