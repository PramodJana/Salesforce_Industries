package me.pranav.OffersItem;

import com.fasterxml.jackson.core.JsonProcessingException;
import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.List;

public class OffersItemAPI {
    private final String accessToken;
    private final String baseUrl;
    private final List<CatalogProfileResponseBody> catalogProfiles;
    private final ResponseRepository repo;

    public OffersItemAPI(String accessToken, String baseUrl, List<CatalogProfileResponseBody> catalogProfiles, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.catalogProfiles = catalogProfiles;
        this.repo = repo;
    }

    public void populateCache() throws InterruptedException, URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = createRequests();
        makeParallelCalls(requests);
    }

    private List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
        OffersItemRequestCreator offersItem = new OffersItemRequestCreator(accessToken, baseUrl, catalogProfiles);
        return offersItem.createRequests();
    }

    private void makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);
        apiService.makeAPICalls();
    }
}
