package me.pranav.Ruleset;

import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class RulesetRequestsCreator {
    private final String accessToken;
    private final String baseUrl;
    private final List<CatalogProfileResponseBody> catalogProfiles;

    public RulesetRequestsCreator(String accessToken, String baseUrl, List<CatalogProfileResponseBody> catalogProfiles) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.catalogProfiles = catalogProfiles;
    }

    public List<HttpRequest> createRequests() throws URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();

        for (CatalogProfileResponseBody catalogProfile : this.catalogProfiles) {
            List<String> rulesets = getAllRulesets(catalogProfile);
            for (String rulesetId : rulesets) {
                HttpRequest request = HttpRequest.newBuilder()
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + this.accessToken)
                        .uri(new URI(this.baseUrl + "ruleset/" + rulesetId + "/rulesetcombinations"))
                        .GET()
                        .build();

                requests.add(request);
            }
        }

        return requests;
    }

    private List<String> getAllRulesets(CatalogProfileResponseBody catalogProfile) {
        List<String> rulesets = new ArrayList<>();
        Collection<List<String>> ruleAssignments = catalogProfile.apiResponse.data.catalogCodeToRuleAssignments.values();

        for (List<String> rulesetAssignment : ruleAssignments)
            rulesets.addAll(rulesetAssignment);

        return rulesets;
    }
}
