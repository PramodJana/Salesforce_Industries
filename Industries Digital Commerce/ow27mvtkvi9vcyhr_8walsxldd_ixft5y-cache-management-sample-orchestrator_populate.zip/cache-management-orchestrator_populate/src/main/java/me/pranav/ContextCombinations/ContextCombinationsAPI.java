package me.pranav.ContextCombinations;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import me.pranav.ContextDimensions.ContextDimensionResponseBody;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

public class ContextCombinationsAPI {
    private final String accessToken;
    private final String baseUrl;
    private final List<ContextDimensionResponseBody> ctxdims;
    private final ResponseRepository repo;
    private final ObjectMapper mapper;

    public ContextCombinationsAPI(String accessToken, String baseUrl, List<ContextDimensionResponseBody> ctxdims, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.ctxdims = ctxdims;
        this.repo = repo;

        this.mapper = new ObjectMapper();
    }

    public List<ContextCombinationResponseBody> populateCache() throws JsonProcessingException, URISyntaxException, InterruptedException {
        List<HttpRequest> requests = createRequests();
        List<String> responseJSONs = makeParallelCalls(requests);

        return convertToDTO(responseJSONs);
    }

    private List<HttpRequest> createRequests() throws JsonProcessingException, URISyntaxException {
        ContextCombinationsRequestCreator ctxCombo = new ContextCombinationsRequestCreator(accessToken, baseUrl, ctxdims);
        return ctxCombo.createRequests();
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);
        return apiService.makeAPICalls();
    }

    private List<ContextCombinationResponseBody> convertToDTO(List<String> responseJSONs) throws JsonProcessingException {
        List<ContextCombinationResponseBody> responses = new ArrayList<>();

        for (String r: responseJSONs) {
            ContextCombinationResponseBody response = mapper.readValue(r, ContextCombinationResponseBody.class);
            responses.add(response);
        }

        return responses;
    }
}
