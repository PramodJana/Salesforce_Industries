package me.pranav.APICallingService;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class RestCallAggregator {
    public static final int APIS_TO_CALL_IN_PARALLEL = 10;
    private final List<HttpRequest> requests;
    private final ResponseRepository repo;
    private final ExecutorService executor;

    public RestCallAggregator(List<HttpRequest> requests, ResponseRepository repo) {
        this.requests = requests;
        this.repo = repo;
        this.executor = Executors.newFixedThreadPool(APIS_TO_CALL_IN_PARALLEL);
    }

    public List<String> makeAPICalls() throws InterruptedException {

        InMemoryClientRepository clientRepo = new InMemoryClientRepository();
        for(int i=0; i < APIS_TO_CALL_IN_PARALLEL + 1; i++){
            HttpClient client = HttpClient.newHttpClient();
            clientRepo.insertClientToRepository(client);
        }

//        System.out.println("total requests : " + requests.size() + " requests : " + requests);
        for(int i=0; i < requests.size(); i++){
            this.executor.submit(new RestCallWorker(clientRepo, requests.get(i), repo));
        }

        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.HOURS);
        System.gc();

        List<String> responses = this.repo.fetchAllResponses();
        this.repo.clear();

        return responses;
    }
}
