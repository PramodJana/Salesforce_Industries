package me.pranav.Offers;

public class OffersRequestBody {
    public String catalogCode;
    public String ctxEligibilityCacheKey;

    public OffersRequestBody(String catalogCode, String ctxEligibilityCacheKey) {
        this.catalogCode = catalogCode;
        this.ctxEligibilityCacheKey = ctxEligibilityCacheKey;
    }
}
