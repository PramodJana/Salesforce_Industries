package me.pranav.ContextCombinations;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextCombinationResponseBody {
    public String cacheKey;
    public String catalogCode;
}
