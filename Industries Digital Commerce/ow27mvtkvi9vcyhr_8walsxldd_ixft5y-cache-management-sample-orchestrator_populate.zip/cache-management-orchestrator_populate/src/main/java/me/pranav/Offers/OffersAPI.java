package me.pranav.Offers;

import com.fasterxml.jackson.core.JsonProcessingException;
import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import me.pranav.ContextEligibility.ContextEligibilityResponseBody;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.List;

public class OffersAPI {
    private final String accessToken;
    private final String baseUrl;
    private final List<ContextEligibilityResponseBody> ctxEligibility;
    private final ResponseRepository repo;

    public OffersAPI(String accessToken, String baseUrl, List<ContextEligibilityResponseBody> ctxEligibility, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.ctxEligibility = ctxEligibility;
        this.repo = repo;
    }

    public void populateCache() throws InterruptedException, URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = createRequests();
        makeParallelCalls(requests);
    }

    private List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
        OffersRequestCreator offers = new OffersRequestCreator(accessToken, baseUrl, ctxEligibility);
        return offers.createRequests();
    }

    private void makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);
        apiService.makeAPICalls();
    }
}
