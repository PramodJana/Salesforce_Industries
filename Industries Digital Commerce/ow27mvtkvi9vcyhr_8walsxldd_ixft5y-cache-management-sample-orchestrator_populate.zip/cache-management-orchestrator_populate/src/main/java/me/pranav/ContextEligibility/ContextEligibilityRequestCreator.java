package me.pranav.ContextEligibility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.ContextCombinations.ContextCombinationResponseBody;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import static java.net.http.HttpRequest.BodyPublishers.ofString;

public class ContextEligibilityRequestCreator {
    private final String accessToken;
    private final String baseUrl;
    private final List<ContextCombinationResponseBody> ctxCombos;
    private final ObjectMapper mapper;

    public ContextEligibilityRequestCreator(String accessToken, String baseUrl, List<ContextCombinationResponseBody> ctxCombos) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.ctxCombos = ctxCombos;

        mapper = new ObjectMapper();
    }


    public List<HttpRequest> createRequests() throws JsonProcessingException, URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();
        for (ContextCombinationResponseBody contextCombinationResponse : ctxCombos) {
            HttpRequest request = createRequest(contextCombinationResponse);
            requests.add(request);
        }
        return requests;
    }

    private HttpRequest createRequest(ContextCombinationResponseBody response) throws JsonProcessingException, URISyntaxException {
        ContextEligibilityRequestBody requestBody = new ContextEligibilityRequestBody(response.catalogCode, response.cacheKey);
        String requestBodyJSON = mapper.writeValueAsString(requestBody);

        return HttpRequest.newBuilder()
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + accessToken)
                .uri(new URI(baseUrl + "catalogs/" + requestBody.catalogCode + "/contexteligibility"))
                .POST(ofString(requestBodyJSON))
                .build();
    }
}
