package me.pranav.ContextCombinations;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.ContextDimensions.ContextDimensionResponseBody;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import static java.net.http.HttpRequest.BodyPublishers.ofString;

public class ContextCombinationsRequestCreator {
    private final String accessToken;
    private final String baseUrl;
    private final List<ContextDimensionResponseBody> contextDimensionResponseBodies;
    public final int CONTEXT_COMBINATIONS_PAGESIZE = 20;
    private final ObjectMapper mapper;

    public ContextCombinationsRequestCreator(String accessToken, String baseUrl, List<ContextDimensionResponseBody> ctxdims) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.contextDimensionResponseBodies = ctxdims;

        this.mapper = new ObjectMapper();
    }

    public List<HttpRequest> createRequests() throws JsonProcessingException, URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();

        for (ContextDimensionResponseBody ctxdim : contextDimensionResponseBodies) {
            int maxCombos = getMaxNumberOfCombos(ctxdim);
            requests.addAll(createRequests(ctxdim, maxCombos));
        }

        return requests;
    }

    private List<HttpRequest> createRequests(ContextDimensionResponseBody ctxdim, int maxCombos) throws JsonProcessingException, URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();

        for (int i = 0; i < maxCombos; i += CONTEXT_COMBINATIONS_PAGESIZE) {
            ContextCombinationRequestBody requestBody = new ContextCombinationRequestBody(ctxdim.catalogCode, i, CONTEXT_COMBINATIONS_PAGESIZE);
            String requestBodyJSON = mapper.writeValueAsString(requestBody);
            HttpRequest request = HttpRequest.newBuilder()
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + accessToken)
                    .uri(new URI(baseUrl + "catalogs/" + requestBody.catalogCode + "/contextcombinations"))
                    .POST(ofString(requestBodyJSON))
                    .build();

            requests.add(request);
        }

        return requests;
    }

    private int getMaxNumberOfCombos(ContextDimensionResponseBody ctxdim) {
        return ctxdim.apiResponse.stream()
                .mapToInt(dimension -> dimension.valuesForCaching.size())
                .reduce(1, (a, b) -> a * b);
    }
}
