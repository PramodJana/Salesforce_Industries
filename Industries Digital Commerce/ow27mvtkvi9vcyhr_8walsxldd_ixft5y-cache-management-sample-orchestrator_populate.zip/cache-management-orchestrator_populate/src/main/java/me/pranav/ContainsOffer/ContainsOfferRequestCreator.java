package me.pranav.ContainsOffer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import static java.net.http.HttpRequest.BodyPublishers.ofString;

public class ContainsOfferRequestCreator {
    private final String accessToken;
    private final String baseUrl;
    private final List<CatalogProfileResponseBody> profiles;
    private final ObjectMapper mapper;

    public ContainsOfferRequestCreator(String accessToken, String baseUrl, List<CatalogProfileResponseBody> profiles) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.profiles = profiles;

        this.mapper = new ObjectMapper();
    }

    public List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = new ArrayList<>();
        for (CatalogProfileResponseBody profile : profiles)
            requests.addAll(createRequests(profile));
        return requests;
    }

    private List<HttpRequest> createRequests(CatalogProfileResponseBody profile) throws URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = new ArrayList<>();
        List<String> products = profile.apiResponse.data.catalogProductRelationDetails.Product;
        for (String product : products) {
            ContainsOfferRequestBody requestBody = new ContainsOfferRequestBody(profile.catalogCode, product, "");
            requests.add(getHttpRequest(requestBody));
        }
        return requests;
    }

    private HttpRequest getHttpRequest(ContainsOfferRequestBody requestBody) throws JsonProcessingException, URISyntaxException {
        String requestBodyJSON = mapper.writeValueAsString(requestBody);

        return HttpRequest.newBuilder()
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + accessToken)
                .uri(new URI(baseUrl + "catalogs/" + requestBody.catalogCode + "/offers/" + requestBody.product + "/containsoffer"))
                .POST(ofString(requestBodyJSON))
                .build();
    }
}
