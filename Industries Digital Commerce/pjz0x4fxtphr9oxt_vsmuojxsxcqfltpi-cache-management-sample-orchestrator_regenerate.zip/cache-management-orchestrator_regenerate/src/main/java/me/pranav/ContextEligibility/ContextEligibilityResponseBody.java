package me.pranav.ContextEligibility;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextEligibilityResponseBody {
    public List<ContextEligibility> apiResponse;
    public String catalogCode;

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ContextEligibility {
        public String eligibilityContextKey;
    }
}

