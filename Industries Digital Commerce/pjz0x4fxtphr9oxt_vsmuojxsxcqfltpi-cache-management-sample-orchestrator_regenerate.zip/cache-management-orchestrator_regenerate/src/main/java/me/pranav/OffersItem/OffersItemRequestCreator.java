package me.pranav.OffersItem;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.net.http.HttpRequest.BodyPublishers.ofString;

public class OffersItemRequestCreator {
    private static final int OFFERS_ITEM_PAGESIZE = 20;
    private final String accessToken;
    private final String baseUrl;
    private final List<CatalogProfileResponseBody> catalogProfiles;
    private final ObjectMapper mapper;

    public OffersItemRequestCreator(String accessToken, String baseUrl, List<CatalogProfileResponseBody> catalogProfiles) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.catalogProfiles = catalogProfiles;

        mapper = new ObjectMapper();
    }

    public List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = new ArrayList<>();
        for (CatalogProfileResponseBody profile : catalogProfiles)
            requests.addAll(createRequests(profile));
        return requests;
    }

    private List<HttpRequest> createRequests(CatalogProfileResponseBody profile) throws URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = new ArrayList<>();
        List<List<String>> pages = paginateOffers(profile);

        for (List<String> page : pages) {
            HttpRequest request = getHttpRequest(profile, page);
            requests.add(request);
        }

        return  requests;
    }

    private List<List<String>> paginateOffers(CatalogProfileResponseBody profile) {
        List<List<String>> pages = new ArrayList<>();
        List<String> allOfferIds = getAllOfferIds(profile);
        int offersCount = allOfferIds.size();

        for (int i = 0; i < offersCount; i += OFFERS_ITEM_PAGESIZE) {
            List<String> page = allOfferIds.subList(i, Math.min(allOfferIds.size(), i + OFFERS_ITEM_PAGESIZE));
            pages.add(page);
        }

        return pages;
    }

    private List<String> getAllOfferIds(CatalogProfileResponseBody profile) {
        List<String> products = profile.apiResponse.data.catalogProductRelationDetails.Product;
        List<String> promotions = profile.apiResponse.data.catalogProductRelationDetails.Promotion;
        return Stream.concat(products.stream(), promotions.stream())
                .collect(Collectors.toList());
    }

    private HttpRequest getHttpRequest(CatalogProfileResponseBody profile, List<String> page) throws JsonProcessingException, URISyntaxException {
        OffersItemRequestBody requestBody = new OffersItemRequestBody(profile.catalogCode, page);
        String requestBodyJSON = mapper.writeValueAsString(requestBody);
        return HttpRequest.newBuilder()
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + accessToken)
                .uri(new URI(baseUrl + "catalogs/" + requestBody.catalogCode + "/offersitem"))
                .POST(ofString(requestBodyJSON))
                .build();
    }
}
