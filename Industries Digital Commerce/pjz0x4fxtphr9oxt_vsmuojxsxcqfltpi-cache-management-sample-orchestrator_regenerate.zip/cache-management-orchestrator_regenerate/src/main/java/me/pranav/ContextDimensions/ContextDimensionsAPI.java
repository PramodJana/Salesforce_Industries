package me.pranav.ContextDimensions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

public class ContextDimensionsAPI {
    private final String accessToken;
    private final String baseUrl;
    private final List<String> catalogCodes;
    private final ResponseRepository repo;
    private final ObjectMapper mapper;

    public ContextDimensionsAPI(String accessToken, String baseUrl, List<String> catalogCodes, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.catalogCodes = catalogCodes;
        this.repo = repo;

        this.mapper = new ObjectMapper();
    }


    public List<ContextDimensionResponseBody> populateCache() throws URISyntaxException, InterruptedException, JsonProcessingException {
        List<HttpRequest> requests = createRequests();
        List<String> responseJSONs = makeParallelCalls(requests);
        return convertToDTO(responseJSONs);
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);
        return apiService.makeAPICalls();
    }

    private List<HttpRequest> createRequests() throws URISyntaxException {
        ContextDimensionsRequestCreator contextDimensions = new ContextDimensionsRequestCreator(accessToken, baseUrl, catalogCodes);
        return contextDimensions.createRequests();
    }

    private List<ContextDimensionResponseBody> convertToDTO(List<String> responseJSONs) throws JsonProcessingException {
        List<ContextDimensionResponseBody> ctxDims = new ArrayList<>();

        for (String e : responseJSONs) {
            ContextDimensionResponseBody ctxDimResponse = mapper.readValue(e, ContextDimensionResponseBody.class);
            ctxDims.add(ctxDimResponse);
        }
        return ctxDims;
    }
}
