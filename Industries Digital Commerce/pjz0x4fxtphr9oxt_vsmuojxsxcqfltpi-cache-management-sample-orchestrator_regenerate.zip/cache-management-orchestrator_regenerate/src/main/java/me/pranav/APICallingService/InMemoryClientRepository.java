package me.pranav.APICallingService;

        import java.net.http.HttpClient;
        import java.util.Deque;
        import java.util.concurrent.ConcurrentLinkedDeque;


public class InMemoryClientRepository {
    Deque<HttpClient> inMemoryClient = new ConcurrentLinkedDeque<>();

    public HttpClient getAvailableClient(){
        return inMemoryClient.pop();
    }

    public void insertClientToRepository(HttpClient client){
        inMemoryClient.push(client);
    }
}