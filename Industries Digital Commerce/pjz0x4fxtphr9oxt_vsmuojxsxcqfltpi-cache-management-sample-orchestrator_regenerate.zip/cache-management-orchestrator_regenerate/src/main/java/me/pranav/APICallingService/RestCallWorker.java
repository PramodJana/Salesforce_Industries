package me.pranav.APICallingService;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
class RestCallWorker implements Runnable {
    private final InMemoryClientRepository clientRepo;
    private final HttpRequest request;
    private final ResponseRepository repo;
    private HttpResponse<String> response;

    public RestCallWorker(InMemoryClientRepository clientRepo, HttpRequest request, ResponseRepository repo) {
        this.request = request;
        this.repo = repo;
        this.clientRepo = clientRepo;
    }
    @Override
    public void run() {
        long startTime = System.currentTimeMillis();
        HttpClient client = clientRepo.getAvailableClient();
        try {
            this.response = client.send(this.request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally{
            clientRepo.insertClientToRepository(client);
            System.gc();
        }
        long endTime = System.currentTimeMillis();
        System.out.println(startTime + " | " + endTime + " | " + (endTime-startTime) + " | " + request.uri() + " | " + response.body());
        this.repo.save(this.response.body());
    }
}
