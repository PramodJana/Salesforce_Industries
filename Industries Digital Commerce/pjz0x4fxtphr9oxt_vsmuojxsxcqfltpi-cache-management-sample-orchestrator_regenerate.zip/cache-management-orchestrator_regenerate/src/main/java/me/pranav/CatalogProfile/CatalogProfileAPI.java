package me.pranav.CatalogProfile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

public class CatalogProfileAPI {

    private final String accessToken;
    private final String baseUrl;
    private final List<String> catalogCodes;
    private final ResponseRepository repo;
    private final ObjectMapper mapper;

    public CatalogProfileAPI(String accessToken, String baseUrl, List<String> catalogCodes, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.catalogCodes = catalogCodes;
        this.repo = repo;

        this.mapper = new ObjectMapper();
    }

    public List<CatalogProfileResponseBody> populateCache() throws URISyntaxException, InterruptedException, JsonProcessingException {
        List<HttpRequest> requests = createRequests();
        List<String> responseJSONs = makeParallelCalls(requests);
        return convertToDTO(responseJSONs);
    }
    
    private List<HttpRequest> createRequests() throws URISyntaxException {
        CatalogProfileRequestCreator catalogProfile = new CatalogProfileRequestCreator(accessToken, baseUrl, catalogCodes);
        return catalogProfile.createRequests();
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);

        return apiService.makeAPICalls();
    }

    private List<CatalogProfileResponseBody> convertToDTO(List<String> responseJSONs) throws JsonProcessingException {
        List<CatalogProfileResponseBody> catalogProfileResponses = new ArrayList<>();
        
        for (String e : responseJSONs) {
            CatalogProfileResponseBody catalogProfileResponseBody = mapper.readValue(e, CatalogProfileResponseBody.class);
            catalogProfileResponses.add(catalogProfileResponseBody);
        }
        return catalogProfileResponses;
    }
}
