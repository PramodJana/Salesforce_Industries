package me.pranav.ContextEligibility;

public class ContextEligibilityRequestBody {
    public String catalogCode;
    public String cachekey;

    public ContextEligibilityRequestBody(String catalogCode, String cachekey) {
        this.catalogCode = catalogCode;
        this.cachekey = cachekey;
    }
}
