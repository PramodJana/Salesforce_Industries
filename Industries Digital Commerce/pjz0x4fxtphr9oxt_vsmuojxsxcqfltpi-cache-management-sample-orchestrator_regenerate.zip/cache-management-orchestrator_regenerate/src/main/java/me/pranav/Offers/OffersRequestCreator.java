package me.pranav.Offers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.ContextEligibility.ContextEligibilityResponseBody;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import static java.net.http.HttpRequest.BodyPublishers.ofString;

public class OffersRequestCreator {

    private final String accessToken;
    private final String baseUrl;
    private final List<ContextEligibilityResponseBody> ctxEligibility;
    private final ObjectMapper mapper;

    public OffersRequestCreator(String accessToken, String baseUrl, List<ContextEligibilityResponseBody> ctxEligibility) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.ctxEligibility = ctxEligibility;

        this.mapper = new ObjectMapper();
    }

    public List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = new ArrayList<>();
        for (ContextEligibilityResponseBody response : ctxEligibility) {
            List<HttpRequest> request = createRequests(response);
            requests.addAll(request);
        }
        return requests;
    }

    private List<HttpRequest> createRequests(ContextEligibilityResponseBody response) throws URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = new ArrayList<>();
        String catalogCode = response.catalogCode;
        for (ContextEligibilityResponseBody.ContextEligibility e : response.apiResponse) {
            HttpRequest request = getHttpRequest(catalogCode, e);
            requests.add(request);
        }
        return requests;
    }

    private HttpRequest getHttpRequest(String catalogCode, ContextEligibilityResponseBody.ContextEligibility e) throws JsonProcessingException, URISyntaxException {
        OffersRequestBody requestBody = new OffersRequestBody(catalogCode, e.eligibilityContextKey);
        String requestBodyJSON = mapper.writeValueAsString(requestBody);
        return HttpRequest.newBuilder()
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + accessToken)
                .uri(new URI(baseUrl + "catalogs/" + requestBody.catalogCode + "/offers"))
                .POST(ofString(requestBodyJSON))
                .build();
    }
}
