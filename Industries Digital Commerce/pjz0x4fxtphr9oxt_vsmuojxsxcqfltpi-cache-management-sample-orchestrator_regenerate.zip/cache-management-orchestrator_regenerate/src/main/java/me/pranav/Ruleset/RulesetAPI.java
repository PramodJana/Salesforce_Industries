package me.pranav.Ruleset;

import com.fasterxml.jackson.databind.ObjectMapper;
import me.pranav.APICallingService.InMemoryImplementation;
import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.List;

public class RulesetAPI {
    private final String accessToken;
    private final String baseUrl;
    private final List<CatalogProfileResponseBody> responses;
    private final ResponseRepository repo;

    public RulesetAPI(String accessToken, String baseUrl, List<CatalogProfileResponseBody> responses, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.responses = responses;
        this.repo = repo;
    }

    public void populateCache() throws InterruptedException, URISyntaxException {
        List<HttpRequest> requests = createRequests();
        makeParallelCalls(requests);
    }

    private List<HttpRequest> createRequests() throws URISyntaxException {
        RulesetRequestsCreator ruleset = new RulesetRequestsCreator(accessToken, baseUrl, responses);
        return ruleset.createRequests();
    }

    private void makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);
        apiService.makeAPICalls();
    }
}
