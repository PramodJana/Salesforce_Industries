package me.pranav.Hierarchy;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.List;

public class HierarchyAPI {
    private final String accessToken;
    private final String baseUrl;
    private final List<CatalogProfileResponseBody> profiles;
    private final ResponseRepository repo;

    public HierarchyAPI(String accessToken, String baseUrl, List<CatalogProfileResponseBody> profiles, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.profiles = profiles;
        this.repo = repo;
    }

    public void populateCache() throws InterruptedException, URISyntaxException {
        List<HttpRequest> requests = createRequests();
        makeParallelCalls(requests);
    }

    private List<HttpRequest> createRequests() throws URISyntaxException {
        HierarchyRequestCreator hierarchy = new HierarchyRequestCreator(accessToken, baseUrl, profiles);
        return hierarchy.createRequests();
    }

    private void makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);
        apiService.makeAPICalls();
    }
}
