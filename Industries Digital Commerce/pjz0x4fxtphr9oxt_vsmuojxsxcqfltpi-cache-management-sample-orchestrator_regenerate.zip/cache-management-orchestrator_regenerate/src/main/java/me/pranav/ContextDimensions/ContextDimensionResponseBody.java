package me.pranav.ContextDimensions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextDimensionResponseBody {
    public List<ContextDimension> apiResponse;
    public String catalogCode;

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ContextDimension {
        public List<String> valuesForCaching;
    }
}
