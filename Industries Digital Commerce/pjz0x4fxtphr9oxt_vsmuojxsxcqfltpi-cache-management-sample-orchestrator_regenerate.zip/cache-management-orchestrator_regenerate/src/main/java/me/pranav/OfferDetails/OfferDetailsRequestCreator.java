package me.pranav.OfferDetails;

import me.pranav.CatalogProfile.CatalogProfileResponseBody;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OfferDetailsRequestCreator {
    private final String accessToken;
    private final String baseUrl;
    private final List<CatalogProfileResponseBody> profiles;

    public OfferDetailsRequestCreator(String accessToken, String baseUrl, List<CatalogProfileResponseBody> profiles) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.profiles = profiles;
    }

    public List<HttpRequest> createRequests() throws URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();
        for (CatalogProfileResponseBody profile : profiles)
            requests.addAll(createRequests(profile));
        return requests;
    }

    private List<HttpRequest> createRequests(CatalogProfileResponseBody profile) throws URISyntaxException {
        List<HttpRequest> requests = new ArrayList<>();
        List<String> allOfferIds = getAllOfferIds(profile);
        for (String offer : allOfferIds)
            requests.add(getHttpRequest(profile, offer));
        return requests;
    }

    private List<String> getAllOfferIds(CatalogProfileResponseBody profile) {
        List<String> products = profile.apiResponse.data.catalogProductRelationDetails.Product;
        List<String> promotions = profile.apiResponse.data.catalogProductRelationDetails.Promotion;
        return Stream.concat(products.stream(), promotions.stream())
                .collect(Collectors.toList());
    }

    private HttpRequest getHttpRequest(CatalogProfileResponseBody profile, String offer) throws URISyntaxException {
        return HttpRequest.newBuilder()
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + accessToken)
                .uri(new URI(baseUrl + "catalogs/" + profile.catalogCode + "/offers/" + offer + "/offerdetails"))
                .POST(HttpRequest.BodyPublishers.ofString("{}"))
                .build();
    }
}
