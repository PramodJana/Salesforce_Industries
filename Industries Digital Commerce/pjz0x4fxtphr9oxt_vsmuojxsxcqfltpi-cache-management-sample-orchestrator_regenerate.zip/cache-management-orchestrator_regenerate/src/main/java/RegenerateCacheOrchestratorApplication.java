import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public class RegenerateCacheOrchestratorApplication {
    public static void main(String[] args) throws URISyntaxException, InterruptedException, IOException {
        String accessToken = "00D5g000005IuZd!AQkAQAExnQ3zSmpU_BYg3Hz2heWsStlDgmxw7S9htqbI3JEKVuoqJZBeuX_QbTT7b7wBQMtmLQUKFNJYdDNJwVzeGgaVIx3v";
        String orgNamespace = "v234_2";
        String instanceUrl = "https://vlocity-2df-dev-ed.my.salesforce.com";
        int catalogPageSize = 2000;
               
        
        //For future dated cache
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
//        String dateTimeString = "2022-10-03T07:55:55";
//        LocalDateTime cacheEffectiveTime = LocalDateTime.parse(dateTimeString, formatter);
//        
//         String cacheEffectiveStartTime = cacheEffectiveTime.toString();

        String cacheEffectiveStartTime = null;

        RegenerateOrchestrator orchestrator = new RegenerateOrchestrator(accessToken, orgNamespace,instanceUrl,catalogPageSize,cacheEffectiveStartTime);
        orchestrator.populateCache();        

        
//      For invoking populate APIs
//      List<String> catalogCodes = List.of("JK_HIER_BUG_hierarchyWithpromo");        
//      PopulateCacheOrchestratorFinalCache orchestrator = new PopulateCacheOrchestratorFinalCache(
//                accessToken, orgNamespace, instanceUrl, catalogCodes);
//
//        orchestrator.populateCache();
    }
}
