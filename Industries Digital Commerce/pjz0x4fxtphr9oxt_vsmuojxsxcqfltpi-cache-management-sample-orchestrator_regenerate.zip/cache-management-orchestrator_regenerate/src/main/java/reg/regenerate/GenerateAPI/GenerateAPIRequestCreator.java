package reg.regenerate.GenerateAPI;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;



import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import me.pranav.APICallingService.ResponseRepository;
import reg.regenerate.AffectedCacheAPI.AffectedResponseBody;
import reg.regenerate.AffectedCacheAPI.Records;


public class GenerateAPIRequestCreator {

	   private final String accessToken;
	   private final List<AffectedResponseBody> affectedResponses;
	   private final ObjectMapper mapper;
	   private static List<String> partialGenerateCatalog = new ArrayList<>();
	   private static List<String> fullGenerateCatalog = new ArrayList<>();
	   public Boolean shouldContainsOfferExecute = false;
	   private final String orgNamespace;
	   private final String instanceUrl;
	   
		   
	    public GenerateAPIRequestCreator(String accessToken,String orgNamespace, String instanceUrl,List<AffectedResponseBody> responses, ResponseRepository repo) {
	        this.accessToken = accessToken;
	        this.orgNamespace = orgNamespace;
	        this.instanceUrl = instanceUrl;
	        this.affectedResponses = responses;
	        
	        mapper = new ObjectMapper();
	    }
	    
	    public List<GenerateModeOrchestrator> createRequests() throws URISyntaxException, JsonProcessingException, InterruptedException {
        	List<GenerateModeOrchestrator> genMode =   new ArrayList<GenerateModeOrchestrator>();
	        List<Records> generateRequestBody = new ArrayList<Records>();

	        for(AffectedResponseBody affectedResponse : affectedResponses)
	        {
	        	 
	        	if(affectedResponse != null && affectedResponse.getRecords() != null && !affectedResponse.getRecords().isEmpty())
	        	{
	        		List<Records> records = affectedResponse.getRecords();
	        		for(Records record : records)
	        		{
	        			if(record.getGenerateAction() != null)
	        			{
	        				List<String> catalogCodes = record.getGenerateAction().getCatalogCodes();
	        				List<String> apiName = record.getGenerateAction().getApiNames();
	        				
	        		        if(apiName.size() == 5 || apiName.size() == 6)
	        				{
	        		        	if(apiName.size() ==6 )
	        		        	{
	        		        		shouldContainsOfferExecute = true;
	        		        	}

	        		        	catalogCodes.removeAll(partialGenerateCatalog);
	        		        	
	        		        	if(catalogCodes != null && !catalogCodes.isEmpty())
	        		        	{
	        		            	partialGenerateCatalog.addAll(catalogCodes);
	        		             }

	        				}
	        				else
	        				{
	        					if(apiName.size() == 13)
	        					{
	        		        		shouldContainsOfferExecute = true;
	        					}
	        		        	catalogCodes.removeAll(fullGenerateCatalog);
	        		        	
	        		        	if(catalogCodes != null && !catalogCodes.isEmpty())
	        		        	{
	        		            	fullGenerateCatalog.addAll(catalogCodes);        		
	        		        	}

	        				}
	        			}
	        		      		
	        		}
	        	}	
	        }
	        
	        System.out.println("PartialGenerate Catalog "+partialGenerateCatalog);
	        System.out.println("fullGenerateCatalog Catalog "+fullGenerateCatalog);
	        System.out.println(" shouldContainsOfferExecute "+shouldContainsOfferExecute);


            if(fullGenerateCatalog != null && !fullGenerateCatalog.isEmpty())
    		{

            	PopulateCacheOrchestrator pco = new PopulateCacheOrchestrator(accessToken, orgNamespace, instanceUrl,fullGenerateCatalog , shouldContainsOfferExecute);
    			
    			pco.populateCache();        		

    		}
            if(partialGenerateCatalog != null && !partialGenerateCatalog.isEmpty())
    		{
    			PopulatePartialCacheOrchestrator pco = new PopulatePartialCacheOrchestrator(accessToken, orgNamespace, instanceUrl,partialGenerateCatalog, shouldContainsOfferExecute);				
				pco.populateCache(); 
    		}
	        
	        return genMode;

	    }

}
