package reg.regenerate.AffectedCacheAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ParamsReq {

	@JsonProperty("isloggedin")
	private Boolean isloggedin;
	
	@JsonProperty("forceRegenerate")
	private Boolean forceRegenerate = false;
	
	@JsonProperty("ChangeResponseId")
	private String ChangeResponseId = null;
	
	
	@JsonProperty("ChangeEntryId")
	private String ChangeEntryId = null;

	
	@JsonProperty("pagesize")
	private String pagesize;
	
	@JsonProperty("offset")
	private String offset;
	
	@JsonProperty("context")
	private String context;
	
	@JsonProperty("method")
	private String method;
	
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	@JsonProperty("forceinvalidatecache")
	private String forceinvalidatecache = "true";
	
	@JsonProperty("actions")
	private String actions = "regenerate";

	@JsonProperty("oldCacheKey")
	private String oldCacheKey;

	@JsonProperty("multiTransactionKey")
	private String multiTransactionKey;
	
	@JsonProperty("effectiveStartTime")
	private String effectiveStartTime;
	
	@JsonProperty("expirationTime")
	private String expirationTime;
	
	public String getExpirationTime() {
		return expirationTime;
	}
	public void setExpirationTime(String expirationTime) {
		this.expirationTime = expirationTime;
	}
	public String getEffectiveStartTime() {
		return effectiveStartTime;
	}
	public void setEffectiveStartTime(String effectiveStartTime) {
		this.effectiveStartTime = effectiveStartTime;
	}
	public String getMultiTransactionKey() {
		return multiTransactionKey;
	}
	public void setMultiTransactionKey(String multiTransactionKey) {
		this.multiTransactionKey = multiTransactionKey;
	}
	public String getOldCacheKey() {
		return oldCacheKey;
	}
	public void setOldCacheKey(String oldCacheKey) {
		this.oldCacheKey = oldCacheKey;
	}
	public String getActions() {
		return actions;
	}
	public void setActions(String actions) {
		this.actions = actions;
	}

	


	public Boolean getForceRegenerate() {
		return forceRegenerate;
	}
	public void setForceRegenerate(Boolean forceRegenerate) {
		this.forceRegenerate = forceRegenerate;
	}
	public String getChangeResponseId() {
		return ChangeResponseId;
	}
	public void setChangeResponseId(String changeResponseId) {
		ChangeResponseId = changeResponseId;
	}
	public String getPagesize() {
		return pagesize;
	}
	public void setPagesize(String pagesize) {
		this.pagesize = pagesize;
	}
	public String getOffset() {
		return offset;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public String getForceinvalidatecache() {
		return forceinvalidatecache;
	}
	public void setForceinvalidatecache(String forceinvalidatecache) {
		this.forceinvalidatecache = forceinvalidatecache;
	}
	



	

	@Override
	public String toString() {
		return "ParamsReq [isloggedin=" + isloggedin + ", forceRegenerate=" + forceRegenerate + ", ChangeResponseId="
				+ ChangeResponseId + ", ChangeEntryId=" + ChangeEntryId + ", pagesize=" + pagesize + ", offset="
				+ offset + ", context=" + context + ", method=" + method + ", forceinvalidatecache="
				+ forceinvalidatecache + ", actions=" + actions + ", oldCacheKey=" + oldCacheKey
				+ ", multiTransactionKey=" + multiTransactionKey + ", effectiveStartTime=" + effectiveStartTime
				+ ", expirationTime=" + expirationTime + "]";
	}
	public Boolean getIsloggedin() {
		return isloggedin;
	}
	public void setIsloggedin(Boolean isloggedin) {
		this.isloggedin = isloggedin;
	}
	public String getChangeEntryId() {
		return ChangeEntryId;
	}
	public void setChangeEntryId(String changeEntryId) {
		ChangeEntryId = changeEntryId;
	}
	
	
	
}
