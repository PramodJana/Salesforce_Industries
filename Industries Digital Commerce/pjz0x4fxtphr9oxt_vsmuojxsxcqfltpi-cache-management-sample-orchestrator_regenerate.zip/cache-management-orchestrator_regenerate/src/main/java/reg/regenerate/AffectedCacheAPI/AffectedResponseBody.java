package reg.regenerate.AffectedCacheAPI;


import java.util.List;


public class AffectedResponseBody {
	
	private List<Records> records;
	private String errorCode;
	private String error;


	@Override
	public String toString() {
		return "GetAffectedEntity [records=" + records + ", errorCode=" + errorCode + ", error=" + error + "]";
	}

	public String getErrorCode() {
		return errorCode;
	}




	public List<Records> getRecords() {
		return records;
	}

	public void setRecords(List<Records> records) {
		this.records = records;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getError() {
		return error;
	}


	public void setError(String error) {
		this.error = error;
	}

}
