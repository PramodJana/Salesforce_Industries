package reg.regenerate.InvalidateAPI;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import reg.regenerate.AffectedCacheAPI.AffectedResponseBody;
import reg.regenerate.DeriveChangeAPI.DeriveChangeRequestCreator;
import reg.regenerate.DeriveChangeAPI.DeriveChangeResponseBody;
import reg.regenerate.GetCatalogChangeAPI.GetCatalogChangeResponseBody;

public class InvalidateAPI {

    private final String accessToken;
    private final String baseUrl;
    private final ResponseRepository repo;
    private final ObjectMapper mapper;
    private final List<AffectedResponseBody> responses;

    public InvalidateAPI(String accessToken, String baseUrl,List<AffectedResponseBody> responses, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.repo = repo;
        this.responses = responses;
        this.mapper = new ObjectMapper();
    }
    
    public List<String> populateCache() throws URISyntaxException, InterruptedException, JsonProcessingException {

        List<HttpRequest> requests = createRequests();
        List<String> responseJSONs = makeParallelCalls(requests);
        return responseJSONs;
    }
    private List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
    	List<HttpRequest> invalidateRequest = new ArrayList<HttpRequest>();
    	InvalidateRequestCreator invalidReq = new InvalidateRequestCreator(accessToken, baseUrl, responses);    		
    	invalidateRequest.addAll(invalidReq.createRequests());
        return invalidateRequest;
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);

        return apiService.makeAPICalls();
    }

}
