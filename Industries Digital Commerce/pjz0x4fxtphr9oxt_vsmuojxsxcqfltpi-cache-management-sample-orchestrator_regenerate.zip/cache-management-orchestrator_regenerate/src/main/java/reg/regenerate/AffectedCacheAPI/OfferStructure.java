package reg.regenerate.AffectedCacheAPI;

import java.util.List;

public class OfferStructure {
	
	private String offerId;
	private List<String> offerIds;
	public OfferStructure(String offerId) {
		super();
		this.offerId = offerId;
	}
	
	public OfferStructure(List<String> offerId) {
		super();
		this.offerIds = offerId;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public List<String> getOfferIds() {
		return offerIds;
	}
	public void setOfferIds(List<String> offerIds) {
		this.offerIds = offerIds;
	}

}
