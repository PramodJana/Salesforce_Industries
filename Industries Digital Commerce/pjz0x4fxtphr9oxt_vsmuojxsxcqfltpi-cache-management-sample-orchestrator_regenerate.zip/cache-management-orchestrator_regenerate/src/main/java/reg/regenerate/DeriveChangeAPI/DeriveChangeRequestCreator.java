package reg.regenerate.DeriveChangeAPI;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import me.pranav.CatalogProfile.CatalogProfileResponseBody;
import reg.regenerate.GetCatalogChangeAPI.GetCatalogChangeResponseBody;

public class DeriveChangeRequestCreator {

   private final String accessToken;
   private final String baseUrl;
   private final List<GetCatalogChangeResponseBody> catalogChangeResponses;
   private final ObjectMapper mapper;
   
	   
    public DeriveChangeRequestCreator(String accessToken, String baseUrl, List<GetCatalogChangeResponseBody> catalogChangeResponses) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.catalogChangeResponses = catalogChangeResponses;
        
        mapper = new ObjectMapper();
    }
    
    public List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
        List<HttpRequest> requests = new ArrayList<>();
        List<DeriveChangeEntityRequestBody> deriveRequestBodyList = new ArrayList<DeriveChangeEntityRequestBody>();

        for(GetCatalogChangeResponseBody catalogChangeResponse : catalogChangeResponses)
        {
        	List<String> cachedAPIChangeIds = catalogChangeResponse.getCachedAPIChangeIds();
        	if(cachedAPIChangeIds != null)
        	{
            	for(String changeId  : cachedAPIChangeIds)
            	{
            		DeriveChangeEntityRequestBody deriveRequestBody = new DeriveChangeEntityRequestBody(changeId);
            		
            		deriveRequestBodyList.add(deriveRequestBody);
            	}        		
        	}	
        }
        for (DeriveChangeEntityRequestBody deriveReqBody : deriveRequestBodyList)
        {
    		String deriveRequestBody = mapper.writeValueAsString(deriveReqBody);
            HttpRequest request = HttpRequest.newBuilder()
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + this.accessToken)
                    .uri(new URI(this.baseUrl + "catalogs/regenerate/deriveChange"))
                    .POST(BodyPublishers.ofString(deriveRequestBody))
                    .build();

            requests.add(request);
        }

        return requests;
    }
}
