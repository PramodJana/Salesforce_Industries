package reg.regenerate.GenerateAPI;

import java.util.List;

public class GenerateModeOrchestrator {
	public GenerateModeOrchestrator(List<String> partialGenerateMode, List<String> fullGenerateMode) {
		super();
		this.partialGenerateMode = partialGenerateMode;
		this.fullGenerateMode = fullGenerateMode;
	}

	private List<String> partialGenerateMode;
	private List<String> fullGenerateMode;
	@Override
	public String toString() {
		return "GenerateMode [partialGenerateMode=" + partialGenerateMode + ", fullGenerateMode=" + fullGenerateMode
				+ "]";
	}
	public List<String> getPartialGenerateMode() {
		return partialGenerateMode;
	}
	public void setPartialGenerateMode(List<String> partialGenerateMode) {
		this.partialGenerateMode = partialGenerateMode;
	}
	public List<String> getFullGenerateMode() {
		return fullGenerateMode;
	}
	public void setFullGenerateMode(List<String> fullGenerateMode) {
		this.fullGenerateMode = fullGenerateMode;
	}

}
