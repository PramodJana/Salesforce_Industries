package reg.regenerate.GetOfferDetailsAPI;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import reg.regenerate.AffectedCacheAPI.Records;
import reg.regenerate.GetOffersAPI.GetOffersRequestCreator;

public class GetOfferDetailsAPI {

    private final String accessToken;
    private final String baseUrl;
    private final ResponseRepository repo;
    private final List<Records> responses;

    public GetOfferDetailsAPI(String accessToken, String baseUrl,List<Records> responses, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.repo = repo;
        this.responses = responses;
    }
    
    public List<String> populateCache() throws URISyntaxException, InterruptedException, IOException {
        List<HttpRequest> requests = createRequests();
        List<String> responseJSONs = makeParallelCalls(requests);
        return responseJSONs;
    }
    private List<HttpRequest> createRequests() throws URISyntaxException, IOException, InterruptedException {
    	List<HttpRequest> offerDetailsRequest = new ArrayList<HttpRequest>();
    	GetOfferDetailsRequestCreator offerDetail = new GetOfferDetailsRequestCreator(accessToken, baseUrl, responses);    		
    	offerDetailsRequest.addAll(offerDetail.createRequests());
        return offerDetailsRequest;
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);

        return apiService.makeAPICalls();
    }

}
