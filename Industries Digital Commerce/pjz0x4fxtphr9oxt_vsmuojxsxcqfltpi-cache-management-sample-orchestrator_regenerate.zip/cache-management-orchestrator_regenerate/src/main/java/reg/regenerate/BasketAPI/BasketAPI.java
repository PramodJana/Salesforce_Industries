package reg.regenerate.BasketAPI;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import reg.regenerate.AffectedCacheAPI.BasketStructure;
import reg.regenerate.AffectedCacheAPI.MtsNode;
import reg.regenerate.AffectedCacheAPI.Records;
import reg.regenerate.DeriveChangeAPI.DeriveChangeResponseBody;
import reg.regenerate.GetOffersAPI.GetOffersRequestCreator;

public class BasketAPI {

    private final String accessToken;
    private final String baseUrl;
    private final String sequence;
    private final ResponseRepository repo;
    private final List<Records> responses;
    private final ObjectMapper mapper;
	public static List<BasketStructure> basketStructureRecordsMts = new ArrayList<BasketStructure>();


    public BasketAPI(String accessToken, String baseUrl,List<Records> responses, ResponseRepository repo, String sequence) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.repo = repo;
        this.responses = responses;
        this.sequence = sequence;
        this.mapper = new ObjectMapper()
	               .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	               
    }
    
    public void populateCache() throws URISyntaxException, InterruptedException, IOException {
        List<HttpRequest> requests = createRequests(responses,sequence);
    	BasketAPIRequestCreator basketAPI = new BasketAPIRequestCreator(accessToken, baseUrl, responses,sequence);  
        List<String> responseJSONs = makeParallelCalls(requests);
        
        //Check for MTS response, if it exists process API calls
        
        //responseJSONs -> passing previous basket response to check for MTS node
        //requests -> passing previous request to get the API URLs
        //basketAPI.basketStructureRecords -> get the post request body from previous request
        
        List<HttpRequest> mtsrequests = convertToDTO(responseJSONs,requests, basketAPI.basketStructureRecords);
        System.out.println("MTS-1 records :: "+basketAPI.basketStructureRecords.size());
        List<String> responseMtsJSON = new ArrayList<String>();
        if(mtsrequests != null && !mtsrequests.isEmpty())
        {
           responseMtsJSON = makeParallelCalls(mtsrequests);        	
        }
        
        //basketStructureRecordsMts -> global varibale to collect the basket request structure
        
        List<HttpRequest> secondmtsrequests = convertToDTO(responseMtsJSON,mtsrequests, basketStructureRecordsMts);
        List<String> secondresponseMtsJSON = new ArrayList<String>();
        
        while(secondmtsrequests != null && !secondmtsrequests.isEmpty()) 
        {
            if(secondmtsrequests != null && !secondmtsrequests.isEmpty())
            {
                secondresponseMtsJSON = makeParallelCalls(secondmtsrequests);        	
            }
        	
            //create request for next MTS call
            secondmtsrequests = convertToDTO(secondresponseMtsJSON,secondmtsrequests, basketStructureRecordsMts);
        	
        }

      
    }
    public List<HttpRequest> createRequests(List<Records> responses, String sequence) throws URISyntaxException, IOException, InterruptedException {
    	List<HttpRequest> basketAPIRequest = new ArrayList<HttpRequest>();
    	BasketAPIRequestCreator basketAPI = new BasketAPIRequestCreator(accessToken, baseUrl, responses,sequence);    		
    	basketAPIRequest.addAll(basketAPI.createRequests());
        return basketAPIRequest;
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);

        return apiService.makeAPICalls();
    }
    
    private List<HttpRequest> convertToDTO(List<String> responseJSONs, List<HttpRequest> request, List<BasketStructure> basketStructureRecords) throws JsonProcessingException {
        List<MtsNode> mtsResponseList = new ArrayList<>();
        List<HttpRequest> requestMtsList = new ArrayList<>();
        basketStructureRecordsMts = new ArrayList<BasketStructure>();
        for (int i=0 ;i<responseJSONs.size()  ; i++)
        {
        	MtsNode mtsResponse = mapper.readValue(responseJSONs.get(i), MtsNode.class);
        	mtsResponseList.add(mtsResponse);
        	if(mtsResponse.getNexttransaction() != null)
            {            	

    	          String multiTransactionKey = mtsResponse.getNexttransaction().getRest().getParams().getMultiTransactionKey();
    	          String methodName = mtsResponse.getNexttransaction().getRest().getParams().getMethod();
//    	          BasketStructure basketStructure = new BasketStructure(multiTransactionKey, methodName);
            	  BasketStructure basketStructure = basketStructureRecords.get(i);
            	  basketStructure.setMultiTransactionKey(multiTransactionKey);
            	  basketStructureRecordsMts.add(basketStructure);
            	  
    	          URI requestUrl = request.get(i).uri();
                  String postRequestBody = mapper.writeValueAsString(basketStructure);
//                  System.out.println("Check the Basket response  "+basketStructure.toString());
				  HttpRequest requestMts = HttpRequest.newBuilder().header("Content-Type", "application/json")
    				                                .header("Authorization", "Bearer " + accessToken)
    				                                .uri(requestUrl)
    				                                .POST(BodyPublishers.ofString(postRequestBody))
    				                                .build();	
				  
				  requestMtsList.add(requestMts);

             }
        }
        

        return requestMtsList;
    }

}
