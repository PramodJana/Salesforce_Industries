package reg.regenerate.GetPromoAndBundleWrapperAPI;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;

import reg.regenerate.AffectedCacheAPI.BundleWrapper;
import reg.regenerate.AffectedCacheAPI.GetOfferDetails;
import reg.regenerate.AffectedCacheAPI.ParamsReq;
import reg.regenerate.AffectedCacheAPI.PromotionWrapper;
import reg.regenerate.AffectedCacheAPI.Records;
import reg.regenerate.AffectedCacheAPI.RestRequest;


public class GetPromoAndBundleWrapperRequestCreator {
	   private final String accessToken;
	   private final String offerbaseUrl;
	   private final List<Records> responses;
	   private final ObjectMapper mapper;
	   
		   
	    public GetPromoAndBundleWrapperRequestCreator(String accessToken, String offerbaseUrl, List<Records> responses) {
	        this.accessToken = accessToken;
	        this.offerbaseUrl = offerbaseUrl;
	        this.responses = responses;
	        
	        mapper = new ObjectMapper();
	    }
	    
	    public List<HttpRequest> createRequests() throws URISyntaxException, IOException, InterruptedException {
	        List<HttpRequest> requests = new ArrayList<>();
	        
	        for (Records record : responses)
	        {
	        	if(record.getSequence() != null && record.getSequence().equalsIgnoreCase("11"))
	        	{
		        	HttpRequest request = getHttpRequest(record, offerbaseUrl);
		            requests.add(request);
	        	}
	        }

	        return requests;
	    }

		private HttpRequest getHttpRequest(Records record, String offerbaseUrl) throws URISyntaxException, IOException, InterruptedException 
		{
			Records.RegenerateAction regenerate = record.getRegenerateAction();
			BundleWrapper bundleWrapper = regenerate.getBundleWrapper();
			PromotionWrapper promoWrapper = regenerate.getPromotionWrapper();
			String postRequestBody = "" ;
			ParamsReq param;
			UriComponentsBuilder builder = null;
			String url = offerbaseUrl;
			HttpRequest request = null;
	        
			if(bundleWrapper != null)
			{
				RestRequest rest =  bundleWrapper.getRest();
				url = url + rest.getLink();

				param = rest.getParams();
				String effectiveStartTime = param.getEffectiveStartTime();
				
				builder = UriComponentsBuilder.fromHttpUrl(url)
				         .queryParam("forceinvalidatecache", param.getForceinvalidatecache())
		                 .queryParam("ChangeEntryId", param.getChangeEntryId());				
			
				 if(effectiveStartTime != null)
				 {
					 builder.queryParam("effectiveStartTime", effectiveStartTime);
				 }

			     request = HttpRequest.newBuilder().header("Content-Type", "application/json")
			             .header("Authorization", "Bearer " + accessToken)
			             .uri(new URI(builder.toUriString()))
			             .POST(BodyPublishers.ofString(postRequestBody))
			             .build();	
			}
			else if(promoWrapper != null)
			{
				RestRequest rest =  promoWrapper.getRest();
				url = url + rest.getLink();
				param = rest.getParams();
				
				String effectiveStartTime = param.getEffectiveStartTime();
				
				builder = UriComponentsBuilder.fromHttpUrl(url)
				         .queryParam("forceinvalidatecache", param.getForceinvalidatecache())
		                 .queryParam("ChangeEntryId", param.getChangeEntryId());				
			
				 if(effectiveStartTime != null)
				 {
					 builder.queryParam("effectiveStartTime", effectiveStartTime);
				 }
				 
				 
	             request = HttpRequest.newBuilder()
	                    .header("Content-Type", "application/json")
	                    .header("Authorization", "Bearer " + accessToken)
	                    .uri(new URI(builder.toUriString()))
	                    .GET()
	                    .build();
			         
			}
			return request;

		}

}
