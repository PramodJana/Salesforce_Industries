package reg.regenerate.AffectedCacheAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MtsNode {

	@JsonProperty("nexttransaction")
	private nexttransaction nexttransaction;
	

	
	@Override
	public String toString() {
		return "MtsNode [nexttransaction=" + nexttransaction.toString() + "]";
	}



	public nexttransaction getNexttransaction() {
		return nexttransaction;
	}



	public void setNexttransaction(nexttransaction nexttransaction) {
		this.nexttransaction = nexttransaction;
	}



	public static class nexttransaction{
		@JsonProperty("rest")
		private RestRequest rest;

		public RestRequest getRest() {
			return rest;
		}

		@Override
		public String toString() {
			return "nexttransaction [rest=" + rest.toString() + "]";
		}

		public void setRest(RestRequest rest) {
			this.rest = rest;
	}
	}
}
