package reg.regenerate.GetCatalogChangeAPI;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

public class GetCatalogChangeRequestCreator {

   private final int pageSize;
   private final int offset;
   private final String accessToken;
   private final String baseUrl;
	@Override
	public String toString() {
		return "GetCatalogChangeRequestCreator [pageSize=" + pageSize + ", offset=" + offset + ", accessToken="
				+ accessToken + ", baseUrl=" + baseUrl + "]";
	}
	public GetCatalogChangeRequestCreator(String accessToken, String baseUrl,int pageSize, int offset) {
		super();
		this.pageSize = pageSize;
		this.offset = offset;
		this.accessToken = accessToken;
		this.baseUrl = baseUrl;
	}
	
	public List<HttpRequest> createRequests() throws URISyntaxException {
	    List<HttpRequest> requests = new ArrayList<>();
    	String catalogUrl = baseUrl + "catalogs/regenerate/catalogChange?pageSize="+this.pageSize+"&offset="+this.offset;
	        HttpRequest request = HttpRequest.newBuilder()
	                .header("Content-Type", "application/json")
	                .header("Authorization", "Bearer " + this.accessToken)
	                .uri(new URI(catalogUrl))
	                .GET()
	                .build();
	
	        requests.add(request);
	
	    return requests;
	}

}