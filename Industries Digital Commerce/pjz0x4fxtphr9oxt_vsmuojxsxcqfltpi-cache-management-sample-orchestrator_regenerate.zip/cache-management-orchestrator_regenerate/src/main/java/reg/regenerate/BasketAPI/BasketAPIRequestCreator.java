package reg.regenerate.BasketAPI;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import reg.regenerate.AffectedCacheAPI.Basket;
import reg.regenerate.AffectedCacheAPI.BasketStructure;
import reg.regenerate.AffectedCacheAPI.GetOffers;
import reg.regenerate.AffectedCacheAPI.Hierarchy;
import reg.regenerate.AffectedCacheAPI.MtsNode;
import reg.regenerate.AffectedCacheAPI.ParamsReq;
import reg.regenerate.AffectedCacheAPI.PostBody;
import reg.regenerate.AffectedCacheAPI.Prices;
import reg.regenerate.AffectedCacheAPI.Records;
import reg.regenerate.AffectedCacheAPI.RestRequest;

public class BasketAPIRequestCreator {
	   private final String accessToken;
	   private final String offerbaseUrl;
       private final String sequence;
	   private final List<Records> responses;
	   public static List<BasketStructure> basketStructureRecords = new ArrayList<BasketStructure>();

	   private final ObjectMapper mapper;
	   		   
	    public BasketAPIRequestCreator(String accessToken, String offerbaseUrl, List<Records> responses, String sequence) {
	        this.accessToken = accessToken;
	        this.offerbaseUrl = offerbaseUrl;
	        this.responses = responses;
	        this.sequence = sequence;
	        
	        mapper = new ObjectMapper();
	    }
	    


		public List<HttpRequest> createRequests() throws URISyntaxException, IOException, InterruptedException {
	        List<HttpRequest> requests = new ArrayList<>();
			basketStructureRecords = new ArrayList<BasketStructure>();
	        for (Records record : responses)
	        {
	        	if(record.getSequence() != null && record.getSequence().equalsIgnoreCase(sequence))
	        	{
		        	HttpRequest request = getHttpRequest(record, offerbaseUrl);
		            requests.add(request);
	        	}
	        }

	        return requests;
	    }

		private HttpRequest getHttpRequest(Records record, String offerbaseUrl) throws URISyntaxException, IOException, InterruptedException 
		{
			Records.RegenerateAction regenerate = record.getRegenerateAction();
			Basket basket = regenerate.getBasket();
			String postRequestBody = "" ;
			ParamsReq param;
			RestRequest rest =  basket.getRest();
			UriComponentsBuilder builder = null;
			String url = offerbaseUrl + rest.getLink();
			param = rest.getParams();
			PostBody requestBody = rest.getPostBody();
			Object offer = requestBody.getOffer();
			String effectiveStartTime = param.getEffectiveStartTime();

			String basketAction = requestBody.getBasketAction();
	        String multiTransactionKey ;

	        BasketStructure basketStructure = new BasketStructure(requestBody.getParentLineItemKey(),requestBody.getParentHierarchyPath(),requestBody.getBundleContextKey(),requestBody.getDeleteBundleNumber(),requestBody.getDeleteBundleNumber(),offer, basketAction);
	        basketStructureRecords.add(basketStructure);
	        Boolean loggedIn = false;
			
		    builder = UriComponentsBuilder.fromHttpUrl(url)
	                .queryParam("forceinvalidatecache", param.getForceinvalidatecache())
	                .queryParam("ChangeEntryId", param.getChangeEntryId())
	                .queryParam("oldCacheKey", param.getOldCacheKey());
		    
			if(param.getIsloggedin() != null && param.getIsloggedin())
			{
				builder.queryParam("isloggedin", param.getIsloggedin());
				builder.queryParam("context", param.getContext());
			}

			if(effectiveStartTime != null)
			{
				builder.queryParam("effectiveStartTime", effectiveStartTime);
			}

			MtsNode result =  null;
			
	        try
	        {
				postRequestBody = mapper.writeValueAsString(basketStructure);
			}
	        catch (JsonProcessingException e)
	        {
				e.printStackTrace();
			}
			
	         HttpRequest request = HttpRequest.newBuilder().header("Content-Type", "application/json")
	                                          .header("Authorization", "Bearer " + accessToken)
	                                          .uri(new URI(builder.toUriString()))
	                                          .POST(BodyPublishers.ofString(postRequestBody))
	                                          .build(); 
	         return request;

		}

}
