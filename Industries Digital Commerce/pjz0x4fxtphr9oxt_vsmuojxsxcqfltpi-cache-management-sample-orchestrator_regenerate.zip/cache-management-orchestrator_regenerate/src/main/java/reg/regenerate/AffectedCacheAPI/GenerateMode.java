package reg.regenerate.AffectedCacheAPI;

import java.util.List;

public class GenerateMode {

	public GenerateMode(List<String> partialGenerateMode, List<String> fullGenerateMode) {
		super();
		this.partialGenerateMode = partialGenerateMode;
		this.fullGenerateMode = fullGenerateMode;
	}

	private List<String> partialGenerateMode;
	private List<String> fullGenerateMode;
	@Override
	public String toString() {
		return "GenerateMode [partialGenerateMode=" + partialGenerateMode + ", fullGenerateMode=" + fullGenerateMode
				+ "]";
	}
	public List<String> getPartialGenerateMode() {
		return partialGenerateMode;
	}
	public void setPartialGenerateMode(List<String> partialGenerateMode) {
		this.partialGenerateMode = partialGenerateMode;
	}
	public List<String> getFullGenerateMode() {
		return fullGenerateMode;
	}
	public void setFullGenerateMode(List<String> fullGenerateMode) {
		this.fullGenerateMode = fullGenerateMode;
	}
	
	public void addPartialorFullCode(List<String> partialGen , List<String> fullGen )
	{
		if((getPartialGenerateMode() != null || !getPartialGenerateMode().isEmpty()) && partialGen != null)
		{
			List<String> records= getPartialGenerateMode();
			records.addAll(fullGen);
			setPartialGenerateMode(records);
		}
		else if(partialGen != null)
		{
			setPartialGenerateMode(partialGen);
		}
		
		if((getFullGenerateMode() != null || !getFullGenerateMode().isEmpty()) && fullGen != null )
		{
			List<String> records= getFullGenerateMode();
			records.addAll(fullGen);
			setFullGenerateMode(records);			
		}
		else if(fullGen != null)
		{
			setFullGenerateMode(fullGen);
		}
		
	}
}
