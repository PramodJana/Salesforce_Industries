package reg.regenerate.GetCatalogChangeAPI;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;

public class GetCatalogChangeAPI {

    private final String accessToken;
    private final String baseUrl;
    private final ResponseRepository repo;
    private final ObjectMapper mapper;
    private final int getCatalogChangePageSize;

    public GetCatalogChangeAPI(String accessToken, String baseUrl, int catalogChangePageSize, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.repo = repo;
        this.getCatalogChangePageSize = catalogChangePageSize;
        this.mapper = new ObjectMapper();
    }
    
    public List<GetCatalogChangeResponseBody> populateCache() throws URISyntaxException, InterruptedException, JsonProcessingException {
        List<HttpRequest> requests = createRequests();
        List<GetCatalogChangeResponseBody> allCatalogChangeResponse = new ArrayList<GetCatalogChangeResponseBody>();
        List<String> responseJSONs = makeParallelCalls(requests);
        List<GetCatalogChangeResponseBody> catalogChangeResponseBody = convertToDTO(responseJSONs);
        int totalChanges = catalogChangeResponseBody.get(0).getTotalChanges();
        
        List<HttpRequest> catalogChangesRequest = createRequests(totalChanges);
        List<String> responseJSONCatalogChange = makeParallelCalls(catalogChangesRequest);
        allCatalogChangeResponse.addAll(convertToDTO(responseJSONCatalogChange));
        allCatalogChangeResponse.addAll(catalogChangeResponseBody);

        return allCatalogChangeResponse;
    }
    private List<HttpRequest> createRequests() throws URISyntaxException {
    	List<HttpRequest> catalogChangeRequest = new ArrayList<HttpRequest>();
    	//for(int offset = 0; offset < 20; offset+=getCatalogChangePageSize)
    	//{
        	GetCatalogChangeRequestCreator catalogChange = new GetCatalogChangeRequestCreator(accessToken, baseUrl, getCatalogChangePageSize, 0);    		
        	catalogChangeRequest.addAll(catalogChange.createRequests());
    	//}
        return catalogChangeRequest;
    }
    
    private List<HttpRequest> createRequests(int totalChanges) throws URISyntaxException {
    	List<HttpRequest> catalogChangeRequest = new ArrayList<HttpRequest>();
    	int totalRecordsComputed =0;
    	for(int offset = getCatalogChangePageSize; offset <= totalChanges; offset+=getCatalogChangePageSize)
    	{
    		totalRecordsComputed = offset;
        	GetCatalogChangeRequestCreator catalogChange = new GetCatalogChangeRequestCreator(accessToken, baseUrl, getCatalogChangePageSize, offset);    		
        	catalogChangeRequest.addAll(catalogChange.createRequests());
    	}

    	int leftOverRecordsToProcess = totalChanges-(totalRecordsComputed+getCatalogChangePageSize);
    	if(leftOverRecordsToProcess > 0)
    	{
        	GetCatalogChangeRequestCreator catalogChange = new GetCatalogChangeRequestCreator(accessToken, baseUrl, getCatalogChangePageSize, totalRecordsComputed+getCatalogChangePageSize);    		
        	catalogChangeRequest.addAll(catalogChange.createRequests());
    	}

        return catalogChangeRequest;
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);

        return apiService.makeAPICalls();
    }

    private List<GetCatalogChangeResponseBody> convertToDTO(List<String> responseJSONs) throws JsonProcessingException {
        List<GetCatalogChangeResponseBody> catalogChangeResponses = new ArrayList<>();
        
        for (String e : responseJSONs) {
        	GetCatalogChangeResponseBody catalogChangeResponseBody = mapper.readValue(e, GetCatalogChangeResponseBody.class);
        	catalogChangeResponses.add(catalogChangeResponseBody);
        }
        return catalogChangeResponses;
    }
}
