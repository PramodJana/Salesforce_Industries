package reg.regenerate.AffectedCacheAPI;


import com.fasterxml.jackson.annotation.JsonProperty;


public class RestRequest{
	
	@JsonProperty("link")
	private String link;
	
	@JsonProperty("method")
	private String method;
	
	@JsonProperty("requestBody")
	private PostBody requestBody;
	
	@JsonProperty("params")
	private ParamsReq params;
	
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	@Override
	public String toString() {
		return "RequestBodyForAction [link=" + link + ", method=" + method + ", requestBody=" + requestBody
				+ ", params=" + params + "]";
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public PostBody getPostBody() {
		return requestBody;
	}
	public void setPostBody(PostBody requestBody) {
		this.requestBody = requestBody;
	}
	public ParamsReq getParams() {
		return params;
	}
	public void setParams(ParamsReq params) {
		this.params = params;
	}
	
}