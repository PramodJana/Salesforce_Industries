package reg.regenerate.AffectedCacheAPI;

import java.util.ArrayList;
import java.util.List;

public class AffectedCacheRequestBody {

		private List<String> cachedAPIChangeIds;

		public AffectedCacheRequestBody(List<String> cachedAPIChangeIds)
		{
			this.cachedAPIChangeIds = cachedAPIChangeIds;
		}

		public AffectedCacheRequestBody(String e) {
			List<String> changeList = new ArrayList<String> ();
			changeList.add(e);
			this.cachedAPIChangeIds = changeList;
		}

		public List<String> getCachedAPIChangeIds() {
			return cachedAPIChangeIds;
		}

		public void setCachedAPIChangeIds(List<String> cachedAPIChangeId) {
			this.cachedAPIChangeIds = cachedAPIChangeId;
		}

		@Override
		public String toString() {
			return "AffectedCacheRequestBody [cachedAPIChangeIds=" + cachedAPIChangeIds + "]";
		}
}
