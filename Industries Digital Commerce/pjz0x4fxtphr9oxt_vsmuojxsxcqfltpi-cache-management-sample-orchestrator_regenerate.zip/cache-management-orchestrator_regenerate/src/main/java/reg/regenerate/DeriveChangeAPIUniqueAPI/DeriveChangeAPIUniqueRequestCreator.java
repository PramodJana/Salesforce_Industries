package reg.regenerate.DeriveChangeAPIUniqueAPI;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class DeriveChangeAPIUniqueRequestCreator {

	   private final String accessToken;
	   private final String baseUrl;
	   private final ObjectMapper mapper;
	   
		   
	    public DeriveChangeAPIUniqueRequestCreator(String accessToken, String baseUrl) {
	        this.accessToken = accessToken;
	        this.baseUrl = baseUrl;
	        
	        mapper = new ObjectMapper();
	    }
	    
	    public List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
	        List<HttpRequest> requests = new ArrayList<>();

	            HttpRequest request = HttpRequest.newBuilder()
	                    .header("Content-Type", "application/json")
	                    .header("Authorization", "Bearer " + this.accessToken)
	                    .uri(new URI(this.baseUrl + "catalogs/regenerate/deriveChange?uniqueDeriveIds=true"))
	                    .POST(HttpRequest.BodyPublishers.ofString("{}"))
	                    .build();

	            requests.add(request);

	        return requests;
	    }
}
