package reg.regenerate.DeriveChangeAPI;

import java.util.ArrayList;
import java.util.List;

public class DeriveChangeResponseBody {
	public DeriveChangeResponseBody() {

	}

	private List<String> cachedAPIChangeIds;
	private List<String> records;
	private String errorCode;
	private String error;

	
	public DeriveChangeResponseBody(String e) {
		List<String> changeList = new ArrayList<String> ();
		changeList.add(e);
		this.cachedAPIChangeIds = changeList;
	}

	@Override
	public String toString() {
		return "DeriveChangeResponseBody [cachedAPIChangeIds=" + cachedAPIChangeIds + ", records=" + records + ", errorCode="
				+ errorCode + ", error=" + error + "]";
	}

	public List<String> getRecords() {
		return records;
	}

	public void setRecords(List<String> records) {
		this.records = records;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public List<String> getCachedAPIChangeIds() {
		return cachedAPIChangeIds;
	}

	public void setCachedAPIChangeIds(List<String> cachedAPIChangeIds) {
		this.cachedAPIChangeIds = cachedAPIChangeIds;
	}

}
