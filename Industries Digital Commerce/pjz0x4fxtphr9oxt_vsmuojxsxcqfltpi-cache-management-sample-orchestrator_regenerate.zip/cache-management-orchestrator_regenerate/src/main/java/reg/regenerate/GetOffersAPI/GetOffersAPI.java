package reg.regenerate.GetOffersAPI;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import reg.regenerate.AffectedCacheAPI.Records;

public class GetOffersAPI {

    private final String accessToken;
    private final String baseUrl;
    private final ResponseRepository repo;
    private final List<Records> responses;

    public GetOffersAPI(String accessToken, String baseUrl,List<Records> responses, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.repo = repo;
        this.responses = responses;
    }
    
    public List<String> populateCache() throws URISyntaxException, InterruptedException, IOException {
        List<HttpRequest> requests = createRequests();
        List<String> responseJSONs = makeParallelCalls(requests);
        return responseJSONs;
    }
    private List<HttpRequest> createRequests() throws URISyntaxException, IOException, InterruptedException {
    	List<HttpRequest> getOffers = new ArrayList<HttpRequest>();
    	GetOffersRequestCreator offersReq = new GetOffersRequestCreator(accessToken, baseUrl, responses);    		
    	getOffers.addAll(offersReq.createRequests());
        return getOffers;
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);

        return apiService.makeAPICalls();
    }

}
