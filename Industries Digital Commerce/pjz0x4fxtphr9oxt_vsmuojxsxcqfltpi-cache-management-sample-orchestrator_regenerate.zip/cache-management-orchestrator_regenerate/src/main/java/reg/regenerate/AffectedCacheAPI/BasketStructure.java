package reg.regenerate.AffectedCacheAPI;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BasketStructure {

	@JsonProperty("multiTransactionKey")
	private String multiTransactionKey;

	@JsonProperty("parentLineItemKey")
	private String parentLineItemKey;
	
	public String getParentLineItemKey() {
		return parentLineItemKey;
	}

	public void setParentLineItemKey(String parentLineItemKey) {
		this.parentLineItemKey = parentLineItemKey;
	}

	public String getParentHierarchyPath() {
		return parentHierarchyPath;
	}

	public void setParentHierarchyPath(String parentHierarchyPath) {
		this.parentHierarchyPath = parentHierarchyPath;
	}

	public String getBundleContextKey() {
		return bundleContextKey;
	}

	public void setBundleContextKey(String bundleContextKey) {
		this.bundleContextKey = bundleContextKey;
	}

	public String getDeleteBundleNumber() {
		return deleteBundleNumber;
	}

	public void setDeleteBundleNumber(String deleteBundleNumber) {
		this.deleteBundleNumber = deleteBundleNumber;
	}

	public String getLineItemKey() {
		return lineItemKey;
	}

	public void setLineItemKey(String lineItemKey) {
		this.lineItemKey = lineItemKey;
	}

	@JsonProperty("parentHierarchyPath")
	private String parentHierarchyPath;
	
	@JsonProperty("bundleContextKey")
	private String bundleContextKey;
	
	@JsonProperty("deleteBundleNumber")
	private String deleteBundleNumber;
	
	@JsonProperty("lineItemKey")
	private String lineItemKey;
	


	public BasketStructure(String parentLineItemKey, String parentHierarchyPath, String bundleContextKey,
			String deleteBundleNumber, String lineItemKey, Object offer, String basketAction) {
		super();
		this.parentLineItemKey = parentLineItemKey;
		this.parentHierarchyPath = parentHierarchyPath;
		this.bundleContextKey = bundleContextKey;
		this.deleteBundleNumber = deleteBundleNumber;
		this.lineItemKey = lineItemKey;
		this.offer = offer;
		this.basketAction = basketAction;
	}

	@Override
	public String toString() {
		return "BasketStructure [multiTransactionKey=" + multiTransactionKey + ", parentLineItemKey="
				+ parentLineItemKey + ", parentHierarchyPath=" + parentHierarchyPath + ", bundleContextKey="
				+ bundleContextKey + ", deleteBundleNumber=" + deleteBundleNumber + ", lineItemKey=" + lineItemKey
				+ ", offer=" + offer + ", basketAction=" + basketAction + "]";
	}

	public String getMultiTransactionKey() {
		return multiTransactionKey;
	}

	public void setMultiTransactionKey(String multiTransactionKey) {
		this.multiTransactionKey = multiTransactionKey;
	}

	public Object getOffer() {
		return offer;
	}

	public void setOffer(Object offer) {
		this.offer = offer;
	}


	public BasketStructure(String multiTransactionKey, Object offer, String basketAction) {
		super();
		this.multiTransactionKey = multiTransactionKey;
		this.offer = offer;
		this.basketAction = basketAction;
	}

	public BasketStructure(String multiTransactionKey, String basketAction) {
		super();
		this.multiTransactionKey = multiTransactionKey;
		this.basketAction = basketAction;

	}
	
	public String getBasketAction() {
		return basketAction;
	}

	public void setBasketAction(String basketAction) {
		this.basketAction = basketAction;
	}

	@JsonProperty("offer")
	private Object offer;
	
	@JsonProperty("basketAction")
	private String basketAction;
}
