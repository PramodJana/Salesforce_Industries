package reg.regenerate.DeriveChangeAPI;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;
import reg.regenerate.GetCatalogChangeAPI.GetCatalogChangeRequestCreator;
import reg.regenerate.GetCatalogChangeAPI.GetCatalogChangeResponseBody;

public class DeriveChangeAPI {

    private final String accessToken;
    private final String baseUrl;
    private final ResponseRepository repo;
    private final ObjectMapper mapper;
    private final List<GetCatalogChangeResponseBody> responses;

    public DeriveChangeAPI(String accessToken, String baseUrl,List<GetCatalogChangeResponseBody> responses, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.repo = repo;
        this.responses = responses;
        this.mapper = new ObjectMapper();
    }
    
    public List<DeriveChangeResponseBody> populateCache() throws URISyntaxException, InterruptedException, JsonProcessingException {
        List<HttpRequest> requests = createRequests();
        List<String> responseJSONs = makeParallelCalls(requests);
        return convertToDTO(responseJSONs);
    }
    private List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
    	List<HttpRequest> deriveChangeRequest = new ArrayList<HttpRequest>();
    	DeriveChangeRequestCreator deriveRequest = new DeriveChangeRequestCreator(accessToken, baseUrl, responses);    		
    	deriveChangeRequest.addAll(deriveRequest.createRequests());
        return deriveChangeRequest;
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);

        return apiService.makeAPICalls();
    }

    private List<DeriveChangeResponseBody> convertToDTO(List<String> responseJSONs) throws JsonProcessingException {
        List<DeriveChangeResponseBody> deriveChangeResponses = new ArrayList<>();
        
        for (String e : responseJSONs) {
        	DeriveChangeResponseBody deriveChangeResponseBody = mapper.readValue(e, DeriveChangeResponseBody.class);
        	deriveChangeResponses.add(deriveChangeResponseBody);
        }
        return deriveChangeResponses;
    }

}
