package reg.regenerate.InvalidateAPI;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InvalidateRequestBody {
	
	@JsonProperty("cachedAPIResponseIds")
	private List<String> cachedAPIResponseIds;
	private String errorCode;
	private String error;
	
	public InvalidateRequestBody(List<String> cachedAPIResponseIds) {
		super();
		this.cachedAPIResponseIds = cachedAPIResponseIds;
	}
	
	public List<String> getCachedAPIResponseIds() {
		return cachedAPIResponseIds;
	}
	public void setCachedAPIResponseIds(List<String> cachedAPIResponseIds) {
		this.cachedAPIResponseIds = cachedAPIResponseIds;
	}
	public String getErrorCode() {
		return errorCode;
	}
	@Override
	public String toString() {
		return "InvalidateRequest [cachedAPIResponseIds=" + cachedAPIResponseIds + ", errorCode=" + errorCode + ", error="
				+ error + "]";
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
}
