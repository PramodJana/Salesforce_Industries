package reg.regenerate.GetCatalogChangeAPI;

import java.util.ArrayList;
import java.util.List;

public class GetCatalogChangeResponseBody {
	public GetCatalogChangeResponseBody() {

	}

	private List<String> cachedAPIChangeIds;
	private int totalChanges;
	public int getTotalChanges() {
		return totalChanges;
	}

	public void setTotalChanges(int totalChanges) {
		this.totalChanges = totalChanges;
	}

	private List<String> records;
	private String errorCode;
	private String error;

	
	public GetCatalogChangeResponseBody(String e) {
		List<String> changeList = new ArrayList<String> ();
		changeList.add(e);
		this.cachedAPIChangeIds = changeList;
	}



	@Override
	public String toString() {
		return "GetCatalogChangeResponseBody [cachedAPIChangeIds=" + cachedAPIChangeIds + ", totalChanges="
				+ totalChanges + ", records=" + records + ", errorCode=" + errorCode + ", error=" + error + "]";
	}

	public List<String> getRecords() {
		return records;
	}

	public void setRecords(List<String> records) {
		this.records = records;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public List<String> getCachedAPIChangeIds() {
		return cachedAPIChangeIds;
	}

	public void setCachedAPIChangeIds(List<String> cachedAPIChangeIds) {
		this.cachedAPIChangeIds = cachedAPIChangeIds;
	}

}
