package reg.regenerate.GetRegenerateActionNode;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import reg.regenerate.AffectedCacheAPI.AffectedResponseBody;
import reg.regenerate.AffectedCacheAPI.Records;
import reg.regenerate.AffectedCacheAPI.Records.RegenerateAction;
import reg.regenerate.InvalidateAPI.InvalidateRequestCreator;

public class GetRegenerateActionNode {
    private final String accessToken;
    private final String baseUrl;
    private final ResponseRepository repo;
    private final ObjectMapper mapper;
    private final List<AffectedResponseBody> responses;

    public GetRegenerateActionNode(String accessToken, String baseUrl,List<AffectedResponseBody> responses, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.repo = repo;
        this.responses = responses;
        this.mapper = new ObjectMapper();
    }
    
    public List<Records> getRegenNodes() throws URISyntaxException, InterruptedException, JsonProcessingException {
        List<Records> regenerateActionNodes = getRegenerateAction(responses);
        return regenerateActionNodes;
    }
    private List<Records> getRegenerateAction(List<AffectedResponseBody> affectedResponses) {
        List<Records> regenerateActionNodes = new ArrayList<>();

        for(AffectedResponseBody affectedResponse : affectedResponses)
        {
        	 
        	if(affectedResponse != null && affectedResponse.getRecords() != null && !affectedResponse.getRecords().isEmpty())
        	{
        		List<Records> records = affectedResponse.getRecords();
        		for(Records record : records)
        		{
        			if(record.getRegenerateAction() != null)
        			{
        				regenerateActionNodes.add(record);
        			}
        		      		
        		}
        	}	
        }
        
        return regenerateActionNodes;
    }    
}
