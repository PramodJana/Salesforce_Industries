package reg.regenerate.AffectedCacheAPI;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;



public class Records {
	
	public Records(RegenerateAction regenerateAction, String sequence) {
		super();
		this.regenerateAction = regenerateAction;
		this.sequence = sequence;
	}
	public Records(GenerateAction generateAction, String sequence) {
		super();
		this.generateAction = generateAction;
		this.sequence = sequence;
	}
	public Records(InvalidateAction invalidateActions, String sequence) {
		super();
		this.invalidateActions = invalidateActions;
		this.sequence = sequence;
	}


	public Records() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Records(InvalidateAction invalidateActions, GenerateAction generateAction, RegenerateAction regenerateAction,
			String sequence) {
		super();
		this.invalidateActions = invalidateActions;
		this.generateAction = generateAction;
		this.regenerateAction = regenerateAction;
		this.sequence = sequence;
	}


	@JsonProperty("invalidateAction")
	private InvalidateAction invalidateActions;
	
	@JsonProperty("generateAction")
	private GenerateAction generateAction;
	
	@JsonProperty("regenerateAction")
	private RegenerateAction regenerateAction;
	
	@JsonProperty("Sequence")
	private String sequence;
	


	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	@Override
	public String toString() {
		return "Records [invalidateActions=" + invalidateActions + ", generateAction=" + generateAction
				+ ", regenerateAction=" + regenerateAction + ", sequence=" + sequence + "]";
	}
	public InvalidateAction getInvalidateAction() {
		return invalidateActions;
	}
	public void setInvalidateAction(InvalidateAction invalidateActions) {
		this.invalidateActions = invalidateActions;
	}
	public GenerateAction getGenerateAction() {
		return generateAction;
	}
	public void setGenerateAction(GenerateAction generateAction) {
		this.generateAction = generateAction;
	}
	public RegenerateAction getRegenerateAction() {
		return regenerateAction;
	}
	public void setRegenerateAction(RegenerateAction regenerateAction) {
		this.regenerateAction = regenerateAction;
	}
	

	public static class InvalidateAction{
		@JsonProperty("invalidateCachedResponse")
		private InvalidateCachedResponse invalidateCachedResponse;

		public InvalidateCachedResponse getInvalidate() {
			return invalidateCachedResponse;
		}

		@Override
		public String toString() {
			return "InvalidateAction [invalidateCachedResponse=" + invalidateCachedResponse + "]";
		}

		public void setInvalidate(InvalidateCachedResponse invalidateCachedResponse) {
			this.invalidateCachedResponse = invalidateCachedResponse;
		}
	}


	public static class InvalidateCachedResponse{
		@JsonProperty("rest")
		private RestRequest rest;

		public RestRequest getRest() {
			return rest;
		}

		public void setRest(RestRequest rest) {
			this.rest = rest;
		}

		@Override
		public String toString() {
			return "InvalidateCachedResponse [rest=" + rest + "]";
		}
	
	}


    public static class GenerateAction{
    	@JsonProperty("CatalogCodes")
		private List<String> CatalogCodes ;

    	@JsonProperty("apiNames")
		private List<String> apiNames ;

		public List<String> getApiNames() {
			return apiNames;
		}

		public void setApiNames(List<String> apiNames) {
			this.apiNames = apiNames;
		}

		@Override
		public String toString() {
			return "GenerateAction [CatalogCodes=" + CatalogCodes + ", apiNames=" + apiNames + "]";
		}

		public List<String> getCatalogCodes() {
			return CatalogCodes;
		}
		public void setCatalogCodes(List<String> catalogCodes) {
			this.CatalogCodes = catalogCodes;
		}
	}
	

    public static class RegenerateAction{
    	@JsonProperty("offersItem")
    	private OffersItem offersItem;
    	
    	@JsonProperty("getOffers")
    	private GetOffers getOffers;
    	
		@Override
		public String toString() {
			return "RegenerateAction [offersItem=" + offersItem + ", getOffers=" + getOffers + ", getOfferDetails="
					+ getOfferDetails + ", promotionWrapper=" + promotionWrapper + ", bundleWrapper=" + bundleWrapper
					+ ", prices=" + prices + ", hierarchy=" + hierarchy + ", basket=" + basket + "]";
		}
		@JsonProperty("getOfferDetails")
    	private GetOfferDetails getOfferDetails;

    	@JsonProperty("promotionWrapper")
    	private PromotionWrapper promotionWrapper;

    	@JsonProperty("bundleWrapper")
    	private BundleWrapper bundleWrapper;
    	
    	@JsonProperty("prices")
    	private Prices prices;
    	
    	@JsonProperty("hierarchy")
    	private Hierarchy hierarchy;
    	
    	@JsonProperty("basket")
    	private Basket basket;
    	
    	public Basket getBasket() {
			return basket;
		}
		public void setBasket(Basket basket) {
			this.basket = basket;
		}
		public OffersItem getOffersItem() {
			return offersItem;
		}
		public void setOffersitem(OffersItem offersItem) {
			this.offersItem = offersItem;
		}
		public GetOffers getGetOffers() {
			return getOffers;
		}
		public void setGetOffers(GetOffers getOffers) {
			this.getOffers = getOffers;
		}
		public GetOfferDetails getGetOfferDetails() {
			return getOfferDetails;
		}
		public void setGetOfferDetails(GetOfferDetails getOfferDetails) {
			this.getOfferDetails = getOfferDetails;
		}
		public PromotionWrapper getPromotionWrapper() {
			return promotionWrapper;
		}
		public void setPromotionWrapper(PromotionWrapper promotionWrapper) {
			this.promotionWrapper = promotionWrapper;
		}
		public BundleWrapper getBundleWrapper() {
			return bundleWrapper;
		}
		public void setBundleWrapper(BundleWrapper bundleWrapper) {
			this.bundleWrapper = bundleWrapper;
		}
		public Prices getPrices() {
			return prices;
		}
		public void setPrices(Prices prices) {
			this.prices = prices;
		}
		public Hierarchy getHierarchy() {
			return hierarchy;
		}
		public void setHierarchy(Hierarchy hierarchy) {
			this.hierarchy = hierarchy;
		}

    }
    
}
