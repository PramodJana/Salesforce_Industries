package reg.regenerate.InvalidateAPI;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import reg.regenerate.AffectedCacheAPI.ParamsReq;
import reg.regenerate.AffectedCacheAPI.PostBody;
import reg.regenerate.AffectedCacheAPI.RestRequest;
import reg.regenerate.AffectedCacheAPI.Records.InvalidateCachedResponse;
import reg.regenerate.AffectedCacheAPI.AffectedCacheRequestBody;
import reg.regenerate.AffectedCacheAPI.AffectedResponseBody;
import reg.regenerate.AffectedCacheAPI.Records;

public class InvalidateRequestCreator {

	   private final String accessToken;
	   private final String baseUrl;
	   private final List<AffectedResponseBody> affectedResponses;
	   private final ObjectMapper mapper;
	   private final int RECORDS_TO_PROCESS_FOR_INVALIDATE_API = 30;
	   private String expirationTime = null;
	   
		   
	    public InvalidateRequestCreator(String accessToken, String baseUrl, List<AffectedResponseBody> affectedResponses) {
	        this.accessToken = accessToken;
	        this.baseUrl = baseUrl;
	        this.affectedResponses = affectedResponses;
	        
	        mapper = new ObjectMapper();
	    }
	    
	    public List<HttpRequest> createRequests() throws URISyntaxException, JsonProcessingException {
	        List<HttpRequest> requests = new ArrayList<>();
	        List<String> invalidateCachedIds = new ArrayList<String>();
	        List<Records> invalidRequestBody = new ArrayList<Records>();
	        
	        List<String> prepareInvalidateCachedAPIResponseIds = new ArrayList<String>();
	        List<InvalidateRequestBody> invalidReqBody = new ArrayList<InvalidateRequestBody>();

	        for(AffectedResponseBody affectedResponse : affectedResponses)
	        {

	        	 
	        	if(affectedResponse != null && affectedResponse.getRecords() != null && !affectedResponse.getRecords().isEmpty())
	        	{
	        		List<Records> records = affectedResponse.getRecords();
	        		for(Records record : records)
	        		{
	        			if(record.getInvalidateAction() != null)
	        			{
	        				invalidRequestBody.add(record);
	        				
	        				//CHANGE NEW START
	        				
	        	    		Records.InvalidateAction invalid = record.getInvalidateAction();
	        	    		InvalidateCachedResponse invalidCacheResponse = invalid.getInvalidate();
	        	    		RestRequest rest = invalidCacheResponse.getRest();
	        	    		PostBody requestBody = rest.getPostBody();
	        	    		ParamsReq param = rest.getParams();
	        	    		expirationTime = param.getExpirationTime();
	        	    		List<String> changeResponseIds = requestBody.getCachedAPIResponseIds();
	        	    		
	        	    		invalidateCachedIds.addAll(changeResponseIds);
	        	    		
	        				//CHANGE NEW END
	        			}
	        		      		
	        		}
	        	}	
	        }
	        
	        
	        for(int id = 0 ; id < invalidateCachedIds.size(); id++)
	        {
	        	prepareInvalidateCachedAPIResponseIds.add(invalidateCachedIds.get(id));
	        	if(prepareInvalidateCachedAPIResponseIds.size() == RECORDS_TO_PROCESS_FOR_INVALIDATE_API)
	        	{
	        		InvalidateRequestBody staleCacheIds = new InvalidateRequestBody(prepareInvalidateCachedAPIResponseIds);
  	        		
             	  invalidReqBody.add(staleCacheIds);  
 	        	   
 	        	  prepareInvalidateCachedAPIResponseIds = new ArrayList<String>();
	        	}
	        }
	        
            if(prepareInvalidateCachedAPIResponseIds.size() > 0)
            {
            	InvalidateRequestBody staleCacheIds = new InvalidateRequestBody(prepareInvalidateCachedAPIResponseIds);
	        		
          	    invalidReqBody.add(staleCacheIds); 

	            prepareInvalidateCachedAPIResponseIds = new ArrayList<String>();
	           
            }
            
            
	        for (InvalidateRequestBody invalidReq : invalidReqBody)
	        {
	            String invaliReqBody = mapper.writeValueAsString(invalidReq);

	    		UriComponentsBuilder builder = null;
	    		
	    		String url = baseUrl + "catalogs/regenerate/invalidate";
				if(expirationTime != null)
				{
					 builder = UriComponentsBuilder.fromHttpUrl(url)
					         .queryParam("expirationTime", expirationTime);			
				}
				else
				{
					 builder = UriComponentsBuilder.fromHttpUrl(url);
				}

				
	          HttpRequest request = HttpRequest.newBuilder().header("Content-Type", "application/json")
	          .header("Authorization", "Bearer " + accessToken)
	          .uri(new URI(builder.toUriString()))
	          .POST(BodyPublishers.ofString(invaliReqBody))
	          .build();   
	          
	          requests.add(request);
	        }
            
            
//	        for (Records invalidReq : invalidRequestBody)
//	        {
//	        	HttpRequest request = getHttpRequest(invalidReq);
//
//	            requests.add(request);
//	        }

	        return requests;
	    }

		private HttpRequest getHttpRequest(Records record) throws JsonProcessingException, URISyntaxException 
		{

    		Records.InvalidateAction invalid = record.getInvalidateAction();
    		InvalidateCachedResponse invalidCacheResponse = invalid.getInvalidate();
    		RestRequest rest = invalidCacheResponse.getRest();
    		PostBody requestBody = rest.getPostBody();
    		ParamsReq param = rest.getParams();
    		String expirationTime = param.getExpirationTime();
    		List<String> changeResponseIds = requestBody.getCachedAPIResponseIds();
            
    		InvalidateRequestBody  invalidRequest = new InvalidateRequestBody(changeResponseIds);
            String invaliReqBody = mapper.writeValueAsString(invalidRequest);

            System.out.println("Check request creator "+invalidRequest.toString());
    		UriComponentsBuilder builder = null;
    		
    		String url = baseUrl + "catalogs/regenerate/invalidate";
			if(expirationTime != null)
			{
				 builder = UriComponentsBuilder.fromHttpUrl(url)
				         .queryParam("expirationTime", expirationTime);			
			}
			else
			{
				 builder = UriComponentsBuilder.fromHttpUrl(url);
			}

			
          HttpRequest request = HttpRequest.newBuilder().header("Content-Type", "application/json")
          .header("Authorization", "Bearer " + accessToken)
          .uri(new URI(builder.toUriString()))
          .POST(BodyPublishers.ofString(invaliReqBody))
          .build();           
   
           return request;			
		}
	    
}
