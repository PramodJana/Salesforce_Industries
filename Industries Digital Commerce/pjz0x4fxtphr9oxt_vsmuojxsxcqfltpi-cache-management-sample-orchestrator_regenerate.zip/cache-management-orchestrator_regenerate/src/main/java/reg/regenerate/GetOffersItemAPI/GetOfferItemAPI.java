package reg.regenerate.GetOffersItemAPI;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;



import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import reg.regenerate.AffectedCacheAPI.Records;

public class GetOfferItemAPI {
    private final String accessToken;
    private final String baseUrl;
    private final ResponseRepository repo;
    private final List<Records> responses;

    public GetOfferItemAPI(String accessToken, String baseUrl,List<Records> responses, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.baseUrl = baseUrl;
        this.repo = repo;
        this.responses = responses;
    }
    
    public List<String> populateCache() throws URISyntaxException, InterruptedException, IOException {
        List<HttpRequest> requests = createRequests();
        List<String> responseJSONs = makeParallelCalls(requests);
        return responseJSONs;
    }
    private List<HttpRequest> createRequests() throws URISyntaxException, IOException, InterruptedException {
    	List<HttpRequest> getOffersItemRequest = new ArrayList<HttpRequest>();
    	GetOffersItemRequestCreator offerItemReq = new GetOffersItemRequestCreator(accessToken, baseUrl, responses);    		
    	getOffersItemRequest.addAll(offerItemReq.createRequests());
        return getOffersItemRequest;
    }

    private List<String> makeParallelCalls(List<HttpRequest> requests) throws InterruptedException {
        RestCallAggregator apiService = new RestCallAggregator(requests, repo);

        return apiService.makeAPICalls();
    }

}
