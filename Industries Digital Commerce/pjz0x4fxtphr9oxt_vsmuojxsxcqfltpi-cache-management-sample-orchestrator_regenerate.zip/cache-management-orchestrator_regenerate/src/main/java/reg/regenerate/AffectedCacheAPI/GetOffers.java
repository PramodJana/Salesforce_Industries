package reg.regenerate.AffectedCacheAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GetOffers {


    	@JsonProperty("rest")
		private RestRequest rest;

		public RestRequest getRest() {
			return rest;
		}

		public void setRest(RestRequest rest) {
			this.rest = rest;
		}
		@Override
		public String toString() {
			return "GetOffers [rest=" + rest + "]";
		}
	
}
