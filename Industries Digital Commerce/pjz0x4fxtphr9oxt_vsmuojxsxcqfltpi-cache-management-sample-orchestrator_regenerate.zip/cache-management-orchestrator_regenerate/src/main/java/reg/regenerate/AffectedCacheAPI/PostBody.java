package reg.regenerate.AffectedCacheAPI;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PostBody {

	
	@JsonProperty("cachedAPIResponseIds")
	private List<String> cachedAPIResponseIds;
	

	@JsonProperty("parentLineItemKey")
	private String parentLineItemKey;
	
	public String getParentLineItemKey() {
		return parentLineItemKey;
	}

	public void setParentLineItemKey(String parentLineItemKey) {
		this.parentLineItemKey = parentLineItemKey;
	}

	public String getParentHierarchyPath() {
		return parentHierarchyPath;
	}

	public void setParentHierarchyPath(String parentHierarchyPath) {
		this.parentHierarchyPath = parentHierarchyPath;
	}

	public String getBundleContextKey() {
		return bundleContextKey;
	}

	public void setBundleContextKey(String bundleContextKey) {
		this.bundleContextKey = bundleContextKey;
	}

	public String getDeleteBundleNumber() {
		return deleteBundleNumber;
	}

	public void setDeleteBundleNumber(String deleteBundleNumber) {
		this.deleteBundleNumber = deleteBundleNumber;
	}

	public String getLineItemKey() {
		return lineItemKey;
	}

	public void setLineItemKey(String lineItemKey) {
		this.lineItemKey = lineItemKey;
	}


	@JsonProperty("parentHierarchyPath")
	private String parentHierarchyPath;
	
	@JsonProperty("bundleContextKey")
	private String bundleContextKey;
	
	@JsonProperty("deleteBundleNumber")
	private String deleteBundleNumber;
	
	@JsonProperty("lineItemKey")
	private String lineItemKey;

	public List<String> getCachedAPIResponseIds() {
		return cachedAPIResponseIds;
	}

	public void setCachedAPIResponseIds(List<String> cachedAPIResponseIds) {
		this.cachedAPIResponseIds = cachedAPIResponseIds;
	}




	@Override
	public String toString() {
		return "PostBody [cachedAPIResponseIds=" + cachedAPIResponseIds + ", parentLineItemKey=" + parentLineItemKey
				+ ", parentHierarchyPath=" + parentHierarchyPath + ", bundleContextKey=" + bundleContextKey
				+ ", deleteBundleNumber=" + deleteBundleNumber + ", lineItemKey=" + lineItemKey + ", offerId=" + offerId
				+ ", offer=" + offer + ", basketAction=" + basketAction + ", offerIds=" + offerIds + "]";
	}


	@JsonProperty("offerId")
	private String offerId;

	@JsonProperty("offer")
	private Object offer;
	
//	@JsonProperty("offer")
//	private String offer;
//
//
//	public String getOffer() {
//		return offer;
//	}
//
//	public void setOffer(String offer) {
//		this.offer = offer;
//	}


	public Object getOffer() {
		return offer;
	}

	public void setOffer(Object offer) {
		this.offer = offer;
	}


	@JsonProperty("basketAction")	
	private String basketAction;
	


	public String getBasketAction() {
		return basketAction;
	}

	public void setBasketAction(String basketAction) {
		this.basketAction = basketAction;
	}

	@JsonProperty("offerIds")
	private List<String> offerIds;





	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public List<String> getOfferIds() {
		return offerIds;
	}

	public void setOfferIds(List<String> offerIds) {
		this.offerIds = offerIds;
	}



}
