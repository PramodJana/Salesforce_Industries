package reg.regenerate.GenerateAPI;
import com.fasterxml.jackson.core.JsonProcessingException;
import me.pranav.APICallingService.InMemoryImplementation;
import me.pranav.APICallingService.ResponseRepository;
import me.pranav.BundleWrapper.BundleWrapperAPI;
import me.pranav.CatalogProfile.CatalogProfileAPI;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;
import me.pranav.ContainsOffer.ContainsOfferAPI;
import me.pranav.ContextCombinations.ContextCombinationResponseBody;
import me.pranav.ContextCombinations.ContextCombinationsAPI;
import me.pranav.ContextDimensions.ContextDimensionResponseBody;
import me.pranav.ContextDimensions.ContextDimensionsAPI;
import me.pranav.ContextEligibility.ContextEligibilityAPI;
import me.pranav.ContextEligibility.ContextEligibilityResponseBody;
import me.pranav.Hierarchy.HierarchyAPI;
import me.pranav.OfferDetails.OfferDetailsAPI;
import me.pranav.Offers.OffersAPI;
import me.pranav.OffersItem.OffersItemAPI;
import me.pranav.Prices.PricesAPI;
import me.pranav.PromotionWrapper.PromotionWrapperAPI;
import me.pranav.Ruleset.RulesetAPI;

import java.net.URISyntaxException;
import java.util.List;

public class PopulateCacheOrchestrator {
    private final String accessToken;
    private final List<String> catalogCodes;
    private final String baseUrl;
    private final ResponseRepository repo;
    private Boolean shouldContainsOfferExecute ;

    public PopulateCacheOrchestrator(String accessToken, String orgNamespace, String instanceUrl, List<String> catalogCodes, Boolean shouldContainsOfferExecute) {
        this.accessToken = accessToken;
        this.catalogCodes = catalogCodes;
        this.baseUrl = instanceUrl + "/services/apexrest/" + orgNamespace + "/v3/admin/";
        this.shouldContainsOfferExecute = shouldContainsOfferExecute;
        this.repo = new InMemoryImplementation();
    }

    public void populateCache() throws URISyntaxException, InterruptedException, JsonProcessingException {

        CatalogProfileAPI catalogProfile = new CatalogProfileAPI(accessToken, baseUrl, catalogCodes, repo);
        List<CatalogProfileResponseBody> catalogProfileResponses = catalogProfile.populateCache();

        RulesetAPI rulesets = new RulesetAPI(accessToken, baseUrl, catalogProfileResponses, repo);
        rulesets.populateCache();

        ContextDimensionsAPI contextDimensions = new ContextDimensionsAPI(accessToken, baseUrl, catalogCodes, repo);
        List<ContextDimensionResponseBody> ctxDims = contextDimensions.populateCache();

        ContextCombinationsAPI contextCombinations = new ContextCombinationsAPI(accessToken, baseUrl, ctxDims, repo);
        List<ContextCombinationResponseBody> ctxCombos = contextCombinations.populateCache();

        ContextEligibilityAPI contextEligibility = new ContextEligibilityAPI(accessToken, baseUrl, ctxCombos, repo);
        List<ContextEligibilityResponseBody> ctxEligibility = contextEligibility.populateCache();

        OffersItemAPI offersItem = new OffersItemAPI(accessToken, baseUrl, catalogProfileResponses, repo);
        offersItem.populateCache();

        OffersAPI offers = new OffersAPI(accessToken, baseUrl, ctxEligibility, repo);
        offers.populateCache();

        HierarchyAPI hierarchy = new HierarchyAPI(accessToken, baseUrl, catalogProfileResponses, repo);
        hierarchy.populateCache();

        PricesAPI prices = new PricesAPI(accessToken, baseUrl, catalogProfileResponses, repo);
        prices.populateCache();

        OfferDetailsAPI offerDetails = new OfferDetailsAPI(accessToken, baseUrl, catalogProfileResponses, repo);
        offerDetails.populateCache();

        BundleWrapperAPI bundleWrapper = new BundleWrapperAPI(accessToken, baseUrl, catalogProfileResponses, repo);
        bundleWrapper.populateCache();

        PromotionWrapperAPI promotionWrapper = new PromotionWrapperAPI(accessToken, baseUrl, catalogProfileResponses, repo);
        promotionWrapper.populateCache();

        if(shouldContainsOfferExecute)
        {
            ContainsOfferAPI containsOffer = new ContainsOfferAPI(accessToken, baseUrl, catalogProfileResponses, repo);
            containsOffer.populateCache();        	
        }

    }
}
