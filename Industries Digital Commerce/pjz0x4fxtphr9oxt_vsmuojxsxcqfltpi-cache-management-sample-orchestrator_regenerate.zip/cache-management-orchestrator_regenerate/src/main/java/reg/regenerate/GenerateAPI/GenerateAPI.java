package reg.regenerate.GenerateAPI;

import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import me.pranav.APICallingService.ResponseRepository;
import me.pranav.APICallingService.RestCallAggregator;
import reg.regenerate.AffectedCacheAPI.AffectedResponseBody;
import reg.regenerate.InvalidateAPI.InvalidateRequestCreator;

public class GenerateAPI {

    private final String accessToken;
    private final ResponseRepository repo;
    private final ObjectMapper mapper;
    private final List<AffectedResponseBody> responses;
    private final String orgNamespace;
    private final String instanceUrl;
    

    public GenerateAPI(String accessToken,String orgNamespace, String instanceUrl,List<AffectedResponseBody> responses, ResponseRepository repo) {
        this.accessToken = accessToken;
        this.repo = repo;
        this.responses = responses;
        this.instanceUrl = instanceUrl;
        this.orgNamespace = orgNamespace;
        this.mapper = new ObjectMapper();
    }
    
    public void populateCache() throws URISyntaxException, InterruptedException, JsonProcessingException {
        List<GenerateModeOrchestrator> requests = createRequests();
    }
    private List<GenerateModeOrchestrator> createRequests() throws URISyntaxException, JsonProcessingException, InterruptedException {
    	List<GenerateModeOrchestrator> genRequest = new ArrayList<GenerateModeOrchestrator>();
    	GenerateAPIRequestCreator gen = new GenerateAPIRequestCreator(accessToken,orgNamespace, instanceUrl,responses , repo);  		
    	genRequest.addAll(gen.createRequests());
        return genRequest;
    }


}
