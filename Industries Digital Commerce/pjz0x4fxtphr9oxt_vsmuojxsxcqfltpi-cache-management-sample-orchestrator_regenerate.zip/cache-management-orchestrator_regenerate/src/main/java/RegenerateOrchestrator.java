import java.io.IOException;
import java.net.URISyntaxException;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;

import me.pranav.APICallingService.InMemoryImplementation;
import me.pranav.APICallingService.ResponseRepository;
import me.pranav.BundleWrapper.BundleWrapperAPI;
import me.pranav.CatalogProfile.CatalogProfileAPI;
import me.pranav.CatalogProfile.CatalogProfileResponseBody;
import me.pranav.ContainsOffer.ContainsOfferAPI;
import me.pranav.ContextCombinations.ContextCombinationResponseBody;
import me.pranav.ContextCombinations.ContextCombinationsAPI;
import me.pranav.ContextDimensions.ContextDimensionResponseBody;
import me.pranav.ContextDimensions.ContextDimensionsAPI;
import me.pranav.ContextEligibility.ContextEligibilityAPI;
import me.pranav.ContextEligibility.ContextEligibilityResponseBody;
import me.pranav.Hierarchy.HierarchyAPI;
import me.pranav.OfferDetails.OfferDetailsAPI;
import me.pranav.Offers.OffersAPI;
import me.pranav.OffersItem.OffersItemAPI;
import me.pranav.Prices.PricesAPI;
import me.pranav.PromotionWrapper.PromotionWrapperAPI;
import me.pranav.Ruleset.RulesetAPI;
import reg.regenerate.AffectedCacheAPI.AffectedCacheAPI;
import reg.regenerate.AffectedCacheAPI.AffectedResponseBody;
import reg.regenerate.AffectedCacheAPI.Records;
import reg.regenerate.AffectedCacheAPI.Records.RegenerateAction;
import reg.regenerate.BasketAPI.BasketAPI;
import reg.regenerate.DeriveChangeAPI.DeriveChangeAPI;
import reg.regenerate.DeriveChangeAPI.DeriveChangeResponseBody;
import reg.regenerate.DeriveChangeAPIUniqueAPI.DeriveChangeAPIUniqueAPI;
import reg.regenerate.GenerateAPI.GenerateAPI;
import reg.regenerate.GetCatalogChangeAPI.GetCatalogChangeAPI;
import reg.regenerate.GetCatalogChangeAPI.GetCatalogChangeResponseBody;
import reg.regenerate.GetHierarchyAPI.GetHierarchyAPI;
import reg.regenerate.GetOfferDetailsAPI.GetOfferDetailsAPI;
import reg.regenerate.GetOffersAPI.GetOffersAPI;
import reg.regenerate.GetOffersItemAPI.GetOfferItemAPI;
import reg.regenerate.GetPricesAPI.GetPricesAPI;
import reg.regenerate.GetPromoAndBundleWrapperAPI.GetPromoAndBundleWrapperAPI;
import reg.regenerate.GetRegenerateActionNode.GetRegenerateActionNode;
import reg.regenerate.InvalidateAPI.InvalidateAPI;

public class RegenerateOrchestrator {

	
	private final String accessToken;
    private final int getCatalogChange;
    private final String baseUrl;
    private final ResponseRepository repo;
    private final String cacheEffectiveStartTime;
    private final String orgNamespace;
    private final String instanceUrl;
    private final String offerbaseUrl;

    public RegenerateOrchestrator(String accessToken, String orgNamespace, String instanceUrl, int catalogChangePage, String cacheEffectiveStartTime) {
        this.accessToken = accessToken;
        this.getCatalogChange = catalogChangePage;
        this.cacheEffectiveStartTime = cacheEffectiveStartTime;
        this.orgNamespace = orgNamespace;
        this.instanceUrl = instanceUrl;
        this.baseUrl = instanceUrl + "/services/apexrest/" + orgNamespace + "/v3/admin/";
        this.offerbaseUrl = instanceUrl + "/services/apexrest/" + orgNamespace + '/';
        this.repo = new InMemoryImplementation();
    }

    public void populateCache() throws URISyntaxException, InterruptedException, IOException {
        long startTime = System.currentTimeMillis();
        System.out.println("START");
        System.out.println("start_time | end_time | elapsed_time | request_URI | response_body");

        GetCatalogChangeAPI catalogChange = new GetCatalogChangeAPI(accessToken, baseUrl,getCatalogChange , repo);
        List<GetCatalogChangeResponseBody> catalogChangeResponse = catalogChange.populateCache();
        
        DeriveChangeAPI deriveChangeAPI = new DeriveChangeAPI(accessToken, baseUrl,catalogChangeResponse , repo);
        List<DeriveChangeResponseBody> deriveChangeRes = deriveChangeAPI.populateCache();
        
        DeriveChangeAPIUniqueAPI deriveChangeAPIUniqueIds = new DeriveChangeAPIUniqueAPI(accessToken, baseUrl, repo);
        List<DeriveChangeResponseBody> deriveChangeResponse = deriveChangeAPIUniqueIds.populateCache();


        AffectedCacheAPI affectedCacheAPI = new AffectedCacheAPI(accessToken, baseUrl,deriveChangeResponse , repo, cacheEffectiveStartTime );
        List<AffectedResponseBody> affectedResponse = affectedCacheAPI.populateCache();

        InvalidateAPI invalidateAPI = new InvalidateAPI(accessToken, baseUrl,affectedResponse , repo);
        List<String> invalidateAPIResponse = invalidateAPI.populateCache();
        
        GenerateAPI generateAPI = new GenerateAPI(accessToken,orgNamespace, instanceUrl,affectedResponse , repo);
        generateAPI.populateCache();
        
        GetRegenerateActionNode regenActionNodes = new GetRegenerateActionNode(accessToken, baseUrl,affectedResponse , repo);
        List<Records> regenerateRecords = regenActionNodes.getRegenNodes();
        
        GetOfferItemAPI offerItem = new GetOfferItemAPI(accessToken, offerbaseUrl,regenerateRecords , repo);
        offerItem.populateCache();
                
        GetHierarchyAPI getHierarchy = new GetHierarchyAPI(accessToken, offerbaseUrl,regenerateRecords , repo);
        getHierarchy.populateCache();
        
        GetPricesAPI getPrices = new GetPricesAPI(accessToken, offerbaseUrl,regenerateRecords , repo);
        getPrices.populateCache();
        
        GetOfferDetailsAPI offerDetails = new GetOfferDetailsAPI(accessToken, offerbaseUrl,regenerateRecords , repo);
        offerDetails.populateCache();

        GetPromoAndBundleWrapperAPI promoAndBundleWrapper = new GetPromoAndBundleWrapperAPI(accessToken, offerbaseUrl,regenerateRecords , repo);
        promoAndBundleWrapper.populateCache();
        
        GetOffersAPI getOffers = new GetOffersAPI(accessToken, offerbaseUrl,regenerateRecords , repo);
        getOffers.populateCache();

        BasketAPI basketAPI = new BasketAPI(accessToken, offerbaseUrl,regenerateRecords , repo, "13");
        List<HttpRequest> requests = basketAPI.createRequests(regenerateRecords, "13");
        
        int basketSequence = 13;        
        while(requests != null && !requests.isEmpty())
        {

            System.out.println("Operating on Basket ::  "+String.valueOf(basketSequence));
            BasketAPI basket = new BasketAPI(accessToken, offerbaseUrl,regenerateRecords , repo, String.valueOf(basketSequence));   
            basket.populateCache();
            
            basketSequence = basketSequence +1;
            requests = basketAPI.createRequests(regenerateRecords, String.valueOf(basketSequence));       
            
        }
        
        System.out.println("time taken ::: "  + (System.currentTimeMillis() - startTime));
    }
    
}
